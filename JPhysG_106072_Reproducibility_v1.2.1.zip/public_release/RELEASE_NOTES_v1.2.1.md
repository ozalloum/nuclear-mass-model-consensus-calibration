# JPhysG-106072 scientific package v1.2.1

This patch supersedes v1.2.0. It removes calendar dates attached to the GSM
data-source decision while preserving the disclosure that digitization was
adopted during revision after inspection. Manuscript, supplement, response
sources and scientific package references are synchronized. The supplement
now identifies the complete current scientific package.

The GSM numerical data are unchanged. Figure 7 presentation is synchronized with the current manuscript (including the in-panel upper-right legends); its plotted numerical values and scales are unchanged. Direct checking against
the supplied journal PDF confirms all 15 values to 0.01 MeV; maximum rounding
difference is 0.0046093 MeV. The archived arXiv geometry check is also retained;
the arXiv PDF was not supplied for this run.

Full scientific reproduction: 43 CSV comparisons pass. Original Fortran source,
Windows bundle, raw output and 21,275-value verification evidence remain.
No fresh Fortran compilation is claimed in this run.

Download JPhysG_106072_Reproducibility_v1.2.1.zip and start with
public_release/README.md. Reviewer correspondence remains in the private
submission package and is excluded from the public scientific release.

The manuscript repository name and published baseline URL have been updated to `ozalloum/nuclear-mass-models` (release `v1.2.1`). The manuscript source, PDF, package README and checksums are synchronized. This is a repository-location correction; scientific data and numerical results are unchanged.
