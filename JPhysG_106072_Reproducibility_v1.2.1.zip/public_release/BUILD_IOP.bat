@echo off
setlocal
cd /d "%~dp0"
if not exist build mkdir build
set "JPHYSG_BUILD=%CD%\build"
cd revision_work\submission
for %%D in (JPhysG_106072_Revised JPhysG_106072_Supplement) do (
  for /L %%P in (1,1,3) do (
    pdflatex -interaction=nonstopmode -halt-on-error -output-directory="%JPHYSG_BUILD%" "%%D.tex"
    if errorlevel 1 exit /b 1
  )
)
endlocal
