# Nuclear-mass model consensus calibration — v1.2.1

**How informative is agreement among nuclear-mass models? Chronology-respecting
tests of error coverage and shell proximity**

Othman H. Y. Zalloum, Palestine Polytechnic University  
Manuscript reference: JPhysG-106072

## Current scientific release

[Release v1.2.1](https://github.com/ozalloum/nuclear-mass-model-consensus-calibration/releases/tag/v1.2.1)

This release adds the audited vector-digitized Gamow shell-model (GSM) values
from Li et al., Phys. Rev. C 102, 034302 (2020), Figure 2(b), to the v1.1.0
scientific baseline. It contains one clean identified manuscript, one numerical
supplement, the analysis code, data, figures, source evidence and verification
records. Earlier releases and the original Git history remain available.

The global-model predictions, frozen protocol, development and confirmation
cohorts, primary mass results and original Fortran evidence are preserved.
GSM is a regional comparator, not a fifth global-ensemble member.

The public manuscript, supplement, analysis script and submission figures are synchronized with the current journal revision. Figure 7 is the current calcium S2n figure with both panel legends inside the upper-right corners; the numerical GSM values and frozen scientific inputs are unchanged.

## Read the paper and data

- [Manuscript PDF](revision_work/submission/JPhysG_106072_Revised.pdf)
- [Numerical supplement PDF](revision_work/submission/JPhysG_106072_Supplement.pdf)
- [Manuscript LaTeX](revision_work/submission/JPhysG_106072_Revised.tex)
- [Supplement LaTeX](revision_work/submission/JPhysG_106072_Supplement.tex)
- [All 15 digitized GSM values](revision_work/raw_source_audit/gsm_vector/Li2020_Fig2b_GSM_digitized.csv)
- [Figure 7](revision_work/figures/FigR_Calcium_global_S2n.pdf)
- [Documented GSM data-source amendment](GSM_PROTOCOL_AMENDMENT.txt)

Both panels of Figure 7 use the same linear scales: mass number A=48–60, ticks
every 2 (display bounds 47.5–60.5), and S2n=0–20 MeV, ticks every 2.5 MeV.
No plotted point or experimental uncertainty bar is clipped. Figure 7 covers
the planned regional case; A=62–72 is archived in Supplement S7.
See [the scale check](FIGURE7_SCALE_CHECK.json).

## Reproduce

Use Python 3.11 or later. From this directory:

```bash
python -m pip install -r requirements.txt
python reproduce_review_package.py --verify-only
python reproduce_review_package.py --output ../JPhysG_106072_reproduction
```

The output directory must be new and outside this package. The runner verifies
SHA-256 integrity, copies the scientific directories, executes the baseline and
revision analyses, rechecks raw-source evidence, and compares all 43 supplied
CSVs to their reproduced or reverified counterparts. It preserves the source
package and records per-step logs and a result JSON. It uses rtol=1e-10 and
atol=1e-12 if a table is not byte-identical.

The default run independently verifies all 21,275 printed DZ31 values from the
retained original massex.out and checks the official program's grid. It does not
claim a new compiler run. To compile and execute the official source as well,
install gfortran and add `--compile-dz31`. The original source distribution,
Windows verification bundle, raw output, run report and checkers are included.

## GSM extraction and comparison

The 48Ca-core and 54Ca-core series are kept separate. A=48 has no GSM point in
the source figure and is not imputed. All six methods are scored on the common
measured subset A=50,52,54,56; the 54Ca-core result has only one measured overlap
in the planned region. AME estimates at A=58,60 are not scored as measurements.
The earlier five-isotope Coraggio/global comparison is retained separately.

The original RQ3 case study was planned. Allowing vector-digitized numerical
inputs was a documented revision-stage amendment, adopted after inspecting the
extracted values. The frozen protocol is unchanged. The original solver outputs
remain unavailable; figure reconstruction is not a recovery of those outputs.
The adopted +/-0.10-MeV allowance is a stress test, not a confidence interval,
theory uncertainty or demonstrated error bound on the original calculations.

All 15 values agree to 0.01 MeV with the journal and arXiv vector coordinates.
The maximum CSV/journal-coordinate difference is 0.00461 MeV; the journal/arXiv
difference is at most 0.00020 MeV. Source hashes, vector coordinates and checks
are in `revision_work/raw_source_audit/gsm_vector/`. Offline reproduction
checks the archived coordinates. A fresh source-PDF check is optional:

```bash
python -m pip install pymupdf
python revision_work/raw_source_audit/gsm_vector/verify_gsm_vector.py --journal-pdf /path/PhysRevC.102.034302.pdf --arxiv-pdf /path/2008.11948v1.pdf
```

Exact source hashes are required. Source-paper PDFs are not redistributed.
The separate Coraggio PDF checker also requires a separately obtained paper.
Both regional comparisons are retrospective. Li et al. used experimental 55Ca
information when setting their potential; the comparison does not establish
independent prospective superiority or causal resolution of false consensus.

## Build the documents

Run `bash BUILD_IOP.sh` on Linux/macOS, or `BUILD_IOP.bat` on Windows, with a
working pdflatex installation. Build products go to `build/`; deposited PDFs
are not overwritten. See [LATEX_README.txt](LATEX_README.txt).

## Directory and validation guide

- `nuclear_mass_repo/`: original standardized data, frozen protocol, locks,
  baseline code and historical outputs. Its figure numbering is historical.
- `revision_work/`: independent revision analysis, raw-source checks, current
  CSV tables and the seven `FigR_*` submission figures.
- `revision_work/submission/`: the sole current manuscript and supplement.
- `SHA256SUMS.json`: checksums of the deposited files, excluding itself.
- `PUBLIC_RELEASE_VALIDATION.json`: checks of this v1.2.1 assembly.
- `REPRODUCTION_RESULT_v1.2.1.json`: completed v1.2.1 numerical reproduction.
- `FIGURE7_SCALE_CHECK.json`: actual plot-axis settings and range checks.

Validation-file counts describe the inputs to the recorded check. Adding a
validation record changes the final manifest count but does not change the
scientific inputs or numerical results.

## Scientific attribution and limits

AME, RIPL, BRUSLIB, the four global models and the two regional calculations
retain their original scientific attribution. No new license is asserted over
third-party materials. The original BRUSLIB HFB-27 conversion and independently
auditable historical fitting rosters remain unavailable. The HFB-27 RIPL check
is an independent comparison within 0.005 MeV. DZ31 agreement concerns 0.01-MeV
printed values, not unrounded outputs or model fitting history.

The protocol records an analysis plan, not independently witnessed
preregistration. The cohorts are clustered and span short historical
extrapolation distances. Experimental mass covariance is unavailable; propagated
calcium S2n bars use quadrature and are approximate. The findings do not establish
calibrated uncertainty for deep neutron-rich extrapolation.
