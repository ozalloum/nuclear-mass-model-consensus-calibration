"""Regenerate the simplified Figure 5 from the unchanged validated table.

This changes only graphic presentation, not bin membership, error statistics,
bootstrap intervals, or any other manuscript result.
"""
from pathlib import Path

import pandas as pd

from audit_analysis import plot_reliability


HERE = Path(__file__).resolve().parent
TABLE = HERE / "tables" / "quintiles_with_bootstrap.csv"
FIGURE = HERE / "figures" / "FigR_RMS_reliability.pdf"


def main() -> None:
    rows = pd.read_csv(TABLE)
    for cohort, expected in (
        ("confirm_primary", [6, 7, 17, 10, 11]),
        ("confirm_broad", [7, 10, 20, 10, 24]),
    ):
        selection = rows[rows["cohort"].eq(cohort)].sort_values("bin")
        if selection["n"].tolist() != expected:
            raise AssertionError(f"Bin counts changed for {cohort}")
    plot_reliability(rows, FIGURE)
    print(f"Redrawn from unchanged source table: {FIGURE}")


if __name__ == "__main__":
    main()
