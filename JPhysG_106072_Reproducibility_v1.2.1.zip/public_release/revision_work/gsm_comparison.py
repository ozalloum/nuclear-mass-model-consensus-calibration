"""Descriptive matched-isotope comparison; GSM remains outside the global ensemble."""
from pathlib import Path
import json
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent


def write_gsm_comparison(ca):
    out=HERE/'tables'
    matched=ca.loc[ca.A.isin([50,52,54,56])].copy()
    assert matched.A.tolist()==[50,52,54,56]
    assert matched.AME2020_S2n_MeV.notna().all()
    columns={m:f'{m}_S2n_MeV' for m in ['FRDM2012','HFB27','DZ31','WS4','Coraggio2020']}
    columns['GSM_core48']='S2n_GSM_core48_MeV'
    metrics=[]
    for model,col in columns.items():
        residual=matched[col]-matched.AME2020_S2n_MeV
        matched[model+'_residual_MeV']=residual
        metrics.append(dict(model=model,n=4,A_values='50;52;54;56',MAE_MeV=float(abs(residual).mean()),
            RMSE_MeV=float(np.sqrt(np.mean(residual**2))),bias_MeV=float(residual.mean())))
    matched.to_csv(out/'calcium_GSM_matched_residuals.csv',index=False)
    pd.DataFrame(metrics).to_csv(out/'calcium_GSM_matched_metrics.csv',index=False)
    sensitivity=[]
    for delta in [0.,.005,.01,.05,.10]:
        for core in [48,54]:
            col=f'S2n_GSM_core{core}_MeV'
            common=ca.dropna(subset=[col,'AME2020_S2n_MeV'])
            error=abs(common[col]-common.AME2020_S2n_MeV)
            lower=np.maximum(error-delta,0);upper=error+delta
            sensitivity.append(dict(core=core,n=len(common),A_values=';'.join(map(str,common.A)),
                adopted_allowance_MeV=delta,MAE_MeV=float(error.mean()),
                MAE_min_MeV=float(lower.mean()),MAE_max_MeV=float(upper.mean()),
                RMSE_min_MeV=float(np.sqrt(np.mean(lower**2))),RMSE_max_MeV=float(np.sqrt(np.mean(upper**2)))))
    pd.DataFrame(sensitivity).to_csv(out/'calcium_GSM_extraction_sensitivity.csv',index=False)
    core=ca.loc[ca.A.isin([56,58,60]),['A','AME2020_S2n_MeV','S2n_GSM_core48_MeV','S2n_GSM_core54_MeV']].copy()
    core['core54_minus_core48_MeV']=core.S2n_GSM_core54_MeV-core.S2n_GSM_core48_MeV
    core.to_csv(out/'calcium_GSM_core_comparison.csv',index=False)
    assert ca.loc[ca.A==48,'S2n_GSM_core48_MeV'].isna().all()
    assert ca.loc[ca.A.isin([58,60]),'AME2020_S2n_MeV'].isna().all()
    report=dict(status='PASS',primary_mass_cohorts_modified=False,global_ensemble_members_modified=False,
        comparison='Retrospective; same AME2020 references and isotope subset for all six rows',
        core_policy='48Ca-core series used on A=50,52,54,56; 54Ca core has one measured overlap, A=56. No stitched core series.',
        uncertainty='Stress-test ranges conditional on independently moving each figure estimate by the stated allowance; not confidence intervals or theory uncertainties.',
        matched_metrics=metrics)
    (out/'GSM_comparison_summary.json').write_text(json.dumps(report,indent=2)+'\n')
    print(pd.DataFrame(metrics).to_string(index=False))


if __name__=='__main__':
    from audit_analysis import calcium_table
    write_gsm_comparison(calcium_table())
