#!/usr/bin/env python3
"""Regenerate seven title-free submission figures; freeze all numerical tables.

The source-data path and numerical methods are the same as the independently
audited analysis. Only graph styling and export formats are altered in v8.
"""

from __future__ import annotations
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
from pandas.testing import assert_frame_equal

import audit_analysis as analysis

HERE = Path(__file__).resolve().parent
DATA = HERE / "tables"
FIG = HERE / "figures"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    frozen = {p.name: sha(p) for p in DATA.glob("*.csv")}
    cfg = json.loads((analysis.ROOT / "stage2a_development/FROZEN_CONFIGURATION_PRE_CONFIRMATION.json").read_text())
    dev = analysis.historical_cohort(2012, 2016)
    con = analysis.historical_cohort(2016, 2020)
    primary = con.loc[con.new_primary_eligible]
    assert len(dev.loc[dev.new_primary_eligible]) == 32
    assert len(primary) == 51 and len(con) == 71
    scored = pd.read_csv(DATA / "confirmation_71_nuclei.csv")
    joined = con.merge(scored[["N", "Z", "D", "E"]], on=["N", "Z"], validate="one_to_one", suffixes=("", "_frozen"))
    assert len(joined) == 71
    assert np.allclose(joined.D, joined.D_frozen, rtol=0, atol=1e-10)
    assert np.allclose(joined.E, joined.E_frozen, rtol=0, atol=1e-10)
    calcium = analysis.calcium_table()
    frozen_ca = pd.read_csv(DATA / "calcium_global_model_S2n.csv")
    assert_frame_equal(calcium, frozen_ca, check_dtype=False, atol=1e-10, rtol=0)
    quintiles = pd.read_csv(DATA / "quintiles_with_bootstrap.csv")

    operations = [
        ("FigR_Chronology", lambda p: analysis.plot_chronology(dev.loc[dev.new_primary_eligible], primary, p)),
        ("FigR_Broad_scatter", lambda p: analysis.plot_scatter(con, p)),
        ("FigR_Coverage_CDF", lambda p: analysis.plot_error_spread_cdf(primary, con, p)),
        ("FigR_Quintiles_CI", lambda p: analysis.plot_quintiles(quintiles, p)),
        ("FigR_RMS_reliability", lambda p: analysis.plot_reliability(quintiles, p)),
        ("FigR_FalseConsensusChart", lambda p: analysis.plot_nuclear_chart(primary, cfg, p)),
        ("FigR_Calcium_global_S2n", lambda p: analysis.plot_calcium(calcium, p)),
    ]
    for stem, op in operations:
        path = FIG / f"{stem}.pdf"
        op(path)
        raster = path.with_suffix(".png")
        assert path.stat().st_size > 2000 and raster.stat().st_size > 12000
        print(f"Figure updated: {path.name}, {raster.name}")
    assert {p.name: sha(p) for p in DATA.glob("*.csv")} == frozen, "Numerical data changed"
    print("PASS: All seven PDF+PNG scientific figures regenerated; all frozen table bytes unchanged.")


if __name__ == "__main__":
    main()
