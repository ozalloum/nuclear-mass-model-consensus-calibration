#!/usr/bin/env python3
"""Reproduce Z-chain bootstrap intervals for MAE and observed coverage.

The original eight numerical result tables remain unchanged.  This is an
independently reproducible, strictly derived addition for Referee 1 point 6.
Resampling entire element (Z) blocks preserves within-chain dependence.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from audit_analysis import BOOT, SEED, historical_cohort


ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "tables" / "cohort_Zblock_coverage_MAE_v9.csv"
METRICS = ROOT / "tables" / "cohort_metrics.csv"


def chain_intervals(group: pd.DataFrame, name: str) -> dict[str, object]:
    """Nonparametric equal-probability resampling of *whole* isotopic chains."""
    stats = []
    for z, g in group.groupby("Z", sort=True):
        err = g["E"].to_numpy(float)
        spread = g["D"].to_numpy(float)
        near = g["near_magic"].to_numpy(int) == 1
        stats.append((int(z), len(g), err.sum(), np.count_nonzero(err <= spread),
                      np.count_nonzero(err <= 2 * spread), np.count_nonzero(near),
                      err[near].sum(), np.count_nonzero(~near), err[~near].sum()))
    blocks = np.asarray(stats, dtype=float)
    n_chains = len(blocks)
    rng = np.random.default_rng(SEED)
    draws = rng.integers(0, n_chains, size=(BOOT, n_chains))
    sampled = blocks[draws]
    n_sampled = sampled[:, :, 1].sum(axis=1)
    values = {
        "MAE_MeV": sampled[:, :, 2].sum(axis=1) / n_sampled,
        "cover_D_frac": sampled[:, :, 3].sum(axis=1) / n_sampled,
        "cover_2D_frac": sampled[:, :, 4].sum(axis=1) / n_sampled,
    }
    near_count = sampled[:, :, 5].sum(axis=1)
    away_count = sampled[:, :, 7].sum(axis=1)
    valid = (near_count > 0) & (away_count > 0)
    near_mean = sampled[valid, :, 6].sum(axis=1) / near_count[valid]
    away_mean = sampled[valid, :, 8].sum(axis=1) / away_count[valid]
    values["near_minus_else_MAE_MeV"] = near_mean - away_mean
    row: dict[str, object] = {
        "cohort": name, "n": len(group), "n_Z_chains": n_chains,
        "bootstrap_seed": SEED, "bootstrap_draws": BOOT,
        "resampling_unit": "isotopic chain (Z)",
        "shell_difference_valid_draws": int(valid.sum()),
    }
    for key, boots in values.items():
        if key == "MAE_MeV":
            observed = float(group["E"].mean())
        elif key == "cover_D_frac":
            observed = float(np.mean(group["E"] <= group["D"]))
        elif key == "near_minus_else_MAE_MeV":
            observed = float(group.loc[group.near_magic == 1, "E"].mean() -
                             group.loc[group.near_magic == 0, "E"].mean())
        else:
            observed = float(np.mean(group["E"] <= 2 * group["D"]))
        low, high = np.quantile(boots, [0.025, 0.975])
        row[key] = observed
        row[key + "_Zblock_ci95_lo"] = float(low)
        row[key + "_Zblock_ci95_hi"] = float(high)
    return row


def main() -> None:
    dev = historical_cohort(2012, 2016)
    confirm = historical_cohort(2016, 2020)
    cohorts = {
        "dev_primary": dev.loc[dev.new_primary_eligible].copy(),
        "dev_broad": dev,
        "confirm_primary": confirm.loc[confirm.new_primary_eligible].copy(),
        "confirm_broad": confirm,
    }
    output = pd.DataFrame([chain_intervals(g, name) for name, g in cohorts.items()])
    original = pd.read_csv(METRICS).set_index("cohort")
    for r in output.itertuples():
        baseline = original.loc[r.cohort]
        assert r.n == int(baseline.n)
        assert r.n_Z_chains == int(baseline.n_Z_chains)
        assert np.isclose(r.MAE_MeV, baseline.MAE_MeV, atol=1e-12)
        assert np.isclose(r.cover_D_frac, baseline.cover_D_frac, atol=1e-12)
        assert np.isclose(r.cover_2D_frac, baseline.cover_2D_frac, atol=1e-12)
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    output.to_csv(OUTPUT, index=False, float_format="%.15g")
    print(output.to_string(index=False, float_format=lambda v: f"{v:.6f}"))
    print(f"Wrote {OUTPUT}")


if __name__ == "__main__":
    main()
