#!/usr/bin/env python3
"""Compare archived mass predictions with original IAEA RIPL-4 files.

No original repository parsing or scoring functions are imported.
AME2020 experimental comparison columns in the RIPL files are not used:
the third width-10 field, Mth, is always the theoretical mass excess.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1] / "nuclear_mass_repo"
RAW = HERE / "official_inputs"
OUT = HERE / "recreated"
FILES = {
    "FRDM2012": "mass-frdm12.dat",
    "HFB27": "mass-hfb27.dat",
    "WS4": "mass-ws4.dat",
}


def parse_model(filename: str) -> tuple[pd.DataFrame, str]:
    source = RAW / filename
    data = source.read_bytes()
    records = []
    for lineno, line in enumerate(data.decode("ascii").splitlines(), start=1):
        # IAEA RIPL-4 model Fortran format:
        # (2i4,1x,a2,1x,i1,3/4f10.3,...).
        # The third f10.3 slot always contains the theoretical mass Mth.
        if not line or line.startswith("#"):
            continue
        try:
            z = int(line[0:4])
            a = int(line[4:8])
        except ValueError:
            continue
        n = a-z
        if n < 0:
            raise AssertionError(f"Impossible RIPL record at line {lineno}")
        mass_piece = line[33:43].strip()
        if not mass_piece:
            continue
        try:
            mth = float(mass_piece)
        except ValueError as exc:
            raise ValueError(f"{filename} line {lineno}: {line!r}") from exc
        records.append({"N":n,"Z":z,"mass_excess_MeV":mth})
    frame = pd.DataFrame.from_records(records)
    if frame.duplicated(["N","Z"]).any():
        raise AssertionError(f"{filename}: duplicate nuclei")
    return frame, hashlib.sha256(data).hexdigest()


def main():
    OUT.mkdir(exist_ok=True)
    rows=[]
    for model,filename in FILES.items():
        raw,sha = parse_model(filename)
        original = pd.read_csv(REPO / f"data/standardized_models/{model}.csv")
        comparison = original.merge(raw,on=["N","Z"],how="left",indicator=True,
                                    suffixes=("_archive","_ripl"),validate="one_to_one")
        if not comparison["_merge"].eq("both").all():
            missing = comparison.loc[comparison["_merge"].ne("both"),["N","Z"]]
            raise AssertionError(f"{model}: archived nuclei missing from official source:\n{missing.head()}")
        diffs = (comparison.mass_excess_MeV_archive-comparison.mass_excess_MeV_ripl).abs()
        largest = float(diffs.max())
        n_exact = int((diffs < 1e-10).sum())
        # Original BRUSLIB HFB-27 export was printed to 0.01 MeV.
        # The independently sourced RIPL-4 copy prints 0.001 MeV.
        tolerance = 0.00501 if model == "HFB27" else 1e-9
        if largest > tolerance:
            raise AssertionError(
                f"{model}: error max {largest} MeV exceeds {tolerance}; "
                f"worst archive rows:\n{comparison.loc[diffs.nlargest(5).index].to_string(index=False)}"
            )
        raw.to_csv(OUT / f"{model}_reparsed_from_ripl4.csv",index=False)
        rows.append({
            "model":model, "source_file":filename,
            "source_url":f"https://github.com/IAEA-NDS/RIPL-4/blob/main/masses/{filename}",
            "source_sha256":sha,
            "official_source_rows":int(len(raw)),
            "archived_rows_all_matched":int(len(original)),
            "exact_agreement":n_exact,
            "max_difference_MeV":largest,
            "tolerance_MeV":tolerance,
            "notes":"HFB-27 is independently cross-validated with a more precise RIPL-4 copy; "
                    "the 8386-case archive is a subset of RIPL-4."
                    if model == "HFB27" else "Exact 0.001-MeV file-precision match",
        })
        print(f"{model}: PASS, {len(original)} archive rows; raw={len(raw)}, "
              f"exact={n_exact}, max difference={largest:.5f} MeV.")
    (HERE/"ripl4_model_audit.json").write_text(json.dumps({"model_audit":rows},indent=2)+"\n")


if __name__ == "__main__":
    main()
