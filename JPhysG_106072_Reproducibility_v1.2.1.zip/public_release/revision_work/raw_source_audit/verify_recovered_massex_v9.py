#!/usr/bin/env python3
"""Independent, byte-preserving verification of recovered DZ31 massex.out.

The Fortran model writes fixed-format (4I4,3F9.2) records. This checker is
separate from the original Fortran verifier and from audit_analysis.py.
"""
from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
RAW = HERE / "DZ31_windows_raw_output" / "massex.out"
REF = HERE.parent.parent / "nuclear_mass_repo" / "data" / "standardized_models" / "DZ31.csv"
OUT = HERE / "DZ31_recovered_raw_verification_v9.json"
EXPECTED_SHA256 = "32ad383091ef86d4ed5af28b2e4ad4caab5cee6bb2194ebae1cb83d0431ffb61"
EXPECTED_N = 21275


def main() -> None:
    raw = RAW.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    if digest != EXPECTED_SHA256:
        raise AssertionError(f"Raw file hash changed: {digest}")
    with REF.open(newline="", encoding="utf-8") as stream:
        records = list(csv.DictReader(stream))
    assert len(records) == EXPECTED_N
    ref: dict[tuple[int, int], float] = {}
    for r in records:
        key = (int(r["N"]), int(r["Z"]))
        assert key not in ref
        ref[key] = float(r["mass_excess_MeV"])
    assert len(ref) == EXPECTED_N

    found: set[tuple[int, int]] = set()
    maximum = 0.0
    lines = raw.splitlines()
    assert len(lines) == EXPECTED_N, f"Expected {EXPECTED_N} raw lines, found {len(lines)}"
    for no, data in enumerate(lines, 1):
        if len(data) != 43:
            raise AssertionError(f"Line {no}: not 43 fixed-width ASCII characters")
        line = data.decode("ascii")
        fields = [line[i * 4:(i + 1) * 4] for i in range(4)]
        fields += [line[16 + j * 9:16 + (j + 1) * 9] for j in range(3)]
        _, z, n, a = (int(f) for f in fields[:4])
        shell, pairing, excess = (float(f) for f in fields[4:])
        assert all(abs(x) < 1.0e6 for x in (shell, pairing, excess))
        assert a == n + z, f"Line {no}: inconsistent A"
        key = (n, z)
        assert key in ref and key not in found, f"Line {no}: bad/duplicate key {key}"
        found.add(key)
        maximum = max(maximum, abs(excess - ref[key]))
    assert found == set(ref), "The raw file and frozen CSV have different nuclear keys"
    assert maximum <= 0.011, f"Maximum raw-vs-CSV error {maximum} MeV"

    output = {
        "status": "PASS", "raw_filename": "massex.out",
        "raw_sha256": digest, "raw_bytes": len(raw),
        "raw_records": len(lines), "archived_DZ31_csv_records": len(ref),
        "fixed_format": "4I4,3F9.2", "key": "(N,Z)",
        "all_mass_numbers_A_match_N_plus_Z": True,
        "all_raw_keys_match_csv": True,
        "maximum_absolute_mass_excess_difference_MeV": maximum,
        "acceptance_tolerance_MeV": 0.011,
        "interpretation": "agreement only at the two-decimal printed precision",
        "claim_excluded": "historical fitting-roster or unrounded floating-point reproducibility",
    }
    OUT.write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
