#!/usr/bin/env python3
"""Recompute the GSM vector audit from archived coordinates.

Optional: --journal-pdf PATH --arxiv-pdf PATH checks coordinates directly
against separately supplied source PDFs. --overlay PATH creates a journal
panel overlay when --journal-pdf is supplied. Offline mode checks archived
coordinates only; it does not pretend to rerun extraction from absent PDFs.
"""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent


def verify_external(source, path):
    import fitz
    if hashlib.sha256(path.read_bytes()).hexdigest() != source['sha256']:
        raise ValueError('PDF hash differs from the audited source; recalibration is required')
    page = fitz.open(path)[source['PDF_page']-1]
    d = page.get_drawings()
    assert len(d) == source['drawing_count']
    for axis in ['x','y']:
        ticks=[getattr(d[i]['rect'],axis+'0') for i in source[axis+'_tick_path_indices']]
        np.testing.assert_allclose(ticks,source[axis+'_ticks_pdf_points'],rtol=0,atol=1e-6)
    for s in source['series']:
        p=d[s['path_index']]
        assert p['color']==(1.,0.,0.) and p['fill'] is None
        assert all(x[0]=='l' for x in p['items'])
        vertices=[list(p['items'][0][1])]+[list(seg[2]) for seg in p['items']]
        np.testing.assert_allclose(vertices,s['vertices'],rtol=0,atol=1e-6)
        for m in s['markers']:
            vertices=[list(seg[1]) for seg in d[m['path_index']]['items'] if seg[0]=='l']
            np.testing.assert_allclose(vertices,m['vertices'],rtol=0,atol=1e-6)
    return page


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--journal-pdf',type=Path)
    cli.add_argument('--arxiv-pdf',type=Path)
    cli.add_argument('--overlay',type=Path)
    args=cli.parse_args()
    archive=json.loads((HERE/'Li2020_vector_geometry.json').read_text())
    csvpath=HERE/'Li2020_Fig2b_GSM_digitized.csv'
    table=list(csv.DictReader(csvpath.open()))
    supplied={(int(r['A']),core):float(r[f'S2n_GSM_core{core}_MeV'])
              for r in table for core in [48,54] if r[f'S2n_GSM_core{core}_MeV']}
    records=[]; diagnostics=[]; direct=[]; journal_page=None; transforms=[]
    for source,pdf in zip(archive['sources'],[args.journal_pdf,args.arxiv_pdf]):
        if pdf:
            page=verify_external(source,pdf)
            direct.append(source['filename'])
            if source is archive['sources'][0]: journal_page=page
        energies=np.array(source['y_tick_MeV']); ticks=np.array(source['y_ticks_pdf_points'])
        slope,intercept=np.polyfit(energies,ticks,1)
        residual=float(np.max(np.abs((ticks-intercept)/slope-energies)))
        assert slope<0 and residual<0.006
        transforms.append((slope,intercept))
        marker_residuals=[]
        for s in source['series']:
            for a,point,m in zip(s['A'],s['vertices'],s['markers']):
                x,y=point
                assert abs(x-source['x_ticks_pdf_points'][(a-50)//2])<0.05
                value=float((y-intercept)/slope)
                rounded=supplied[a,s['core']]
                assert f'{value:.2f}'==f'{rounded:.2f}'
                marker_residuals.append(abs(np.mean(np.array(m['vertices'])[:,1])-y)/abs(slope))
                records.append(dict(source=source['filename'],PDF_page=source['PDF_page'],A=a,
                    core=s['core'],CSV_S2n_MeV=rounded,PDF_vector_S2n_MeV=value,
                    CSV_minus_vector_MeV=rounded-value))
        diagnostics.append(dict(source=source['filename'],PDF_page=source['PDF_page'],
            verified_points=15,max_axis_tick_fit_residual_MeV=residual,
            max_marker_centroid_vs_polyline_MeV=float(max(marker_residuals))))
    records.sort(key=lambda r:(r['source'],r['A'],r['core']))
    with (HERE/'Li2020_vector_audit_both_PDFs.csv').open('w',newline='') as stream:
        w=csv.DictWriter(stream,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
    journal={(r['A'],r['core']):r['PDF_vector_S2n_MeV'] for r in records if r['source'].startswith('PhysRev')}
    arxiv={(r['A'],r['core']):r['PDF_vector_S2n_MeV'] for r in records if r['source'].startswith('2008')}
    summary=dict(status='PASS',date='2026-11-02',source_diagnostics=diagnostics,
        max_journal_vs_arxiv_difference_MeV=max(abs(v-arxiv[k]) for k,v in journal.items()),
        max_CSV_vs_journal_difference_MeV=max(abs(supplied[k]-v) for k,v in journal.items()),
        CSV_sha256=hashlib.sha256(csvpath.read_bytes()).hexdigest(),
        sources=[dict(filename=s['filename'],sha256=s['sha256'],PDF_page=s['PDF_page']) for s in archive['sources']],
        uncertainty_note='0.10 MeV is an adopted stress-test allowance, not a statistical error, a proven bound on original outputs, or a GSM model uncertainty.')
    (HERE/'GSM_vector_verification.json').write_text(json.dumps(summary,indent=2)+'\n')
    if direct:
        (HERE/'GSM_external_PDF_check.json').write_text(json.dumps(dict(date='2026-11-02',status='PASS',
            independently_supplied_PDFs_checked=direct,coordinate_tolerance_pdf_points=1e-6),indent=2)+'\n')
    if args.overlay:
        if journal_page is None:cli.error('--overlay requires --journal-pdf')
        import fitz
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        clip=fitz.Rect(27,218,291,391)
        pix=journal_page.get_pixmap(matrix=fitz.Matrix(4,4),clip=clip,alpha=False)
        bg=np.frombuffer(pix.samples,dtype=np.uint8).reshape(pix.height,pix.width,pix.n)
        fig,ax=plt.subplots(figsize=(9,6.6))
        ax.imshow(bg,extent=(clip.x0,clip.x1,clip.y1,clip.y0),origin='upper')
        slope,intercept=transforms[0]
        source=archive['sources'][0]
        for core,color,marker in [(48,'#0072b2','o'),(54,'#8e44ad','s')]:
            series=next(s for s in source['series'] if s['core']==core)
            xs=[source['x_ticks_pdf_points'][(a-50)//2] for a in series['A']]
            ys=[intercept+slope*supplied[a,core] for a in series['A']]
            ax.plot(xs,ys,ls='none',marker=marker,mfc='none',mec=color,mew=1.5,ms=10,
                    label=f'CSV: {core}Ca core')
        ax.axis('off');ax.legend(loc='upper center',bbox_to_anchor=(.5,-.02),ncol=2,frameon=False)
        fig.suptitle('GSM CSV over the published Figure 2(b)',fontsize=14)
        fig.text(.5,.025,'Li et al., Phys. Rev. C 102, 034302 (2020), p. 5. Figure-derived estimates.',ha='center',fontsize=9)
        fig.subplots_adjust(top=.91,bottom=.15,left=.02,right=.99)
        fig.savefig(args.overlay,dpi=180)
        plt.close(fig)
    print(json.dumps(summary,indent=2))
    print('Direct PDF checks this run:',direct or 'not requested; archived coordinate audit only')


if __name__=='__main__':main()
