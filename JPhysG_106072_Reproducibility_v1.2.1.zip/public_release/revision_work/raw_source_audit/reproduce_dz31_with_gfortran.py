#!/usr/bin/env python3
"""Check official AMDC dz31.f against the archived 21,275-row DZ31 table.

The AMDC source is included as an unmodified member dz31.f inside
official_inputs/Duflo-Zuker-program.zip.  `--verify-grid` checks source
provenance and membership without compiling.  `--run` requires gfortran,
compiles in a temporary directory and checks every two-decimal prediction.

The executed model calculation has NOT been verified on systems lacking
gfortran. The script does not alter the tagged source repository.
"""

from __future__ import annotations

import argparse
import io
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import zipfile

import pandas as pd


HERE = Path(__file__).resolve().parent
ZIP = HERE / "official_inputs" / "Duflo-Zuker-program.zip"
ARCHIVED = HERE.parents[1] / "nuclear_mass_repo/data/standardized_models/DZ31.csv"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--verify-grid", action="store_true")
    mode.add_argument("--run", action="store_true")
    args = parser.parse_args()

    with zipfile.ZipFile(ZIP) as archive:
        source = archive.read("dz31.f").decode("ascii", errors="replace")
    assert re.search(r"do\s+10\s+kz\s*=\s*6\s*,\s*120", source, re.I)
    assert re.search(r"do\s+10\s+kn\s*=\s*6\s*,\s*190", source, re.I)
    assert re.search(r"format\s*\(4i4,3f9\.2\)", source, re.I)
    tab = pd.read_csv(ARCHIVED)
    expected = {(int(r.N), int(r.Z)): float(r.mass_excess_MeV) for r in tab.itertuples()}
    assert len(expected) == len(tab) == (120 - 6 + 1) * (190 - 6 + 1) == 21275
    assert set(expected) == {(n, z) for z in range(6, 121) for n in range(6, 191)}
    print("PASS: official dz31.f source generates the same 21,275-point (N,Z) grid")

    if args.verify_grid:
        print("NOT RUN: numerical mass values require --run and a gfortran compiler")
        return

    compiler = shutil.which("gfortran")
    if not compiler:
        raise RuntimeError("Numerical DZ31 reproduction not run: gfortran is not available")
    with tempfile.TemporaryDirectory(prefix="dz31_audit_") as tmp:
        folder = Path(tmp)
        file = folder / "dz31.f"
        file.write_text(source, encoding="ascii", errors="replace")
        exe = folder / "dz31"
        subprocess.run([compiler, "-std=legacy", "-ffixed-line-length-none", "-O0",
                        "-o", str(exe), str(file)], check=True, cwd=folder)
        subprocess.run([str(exe)], check=True, cwd=folder, timeout=240)
        observed = {}
        with (folder / "massex.out").open(encoding="ascii") as stream:
            for line in stream:
                assert len(line.rstrip("\n")) >= 43, line
                z, n = int(line[4:8]), int(line[8:12])
                a = int(line[12:16])
                assert a == n + z
                observed[(n, z)] = float(line[34:43])
        assert observed.keys() == expected.keys()
        largest = max(abs(observed[k] - expected[k]) for k in expected)
        # Both tables carry two-decimal rounded values. Compiler-dependent
        # Fortran arithmetic at a half-cent boundary could differ by .01 MeV.
        assert largest <= 0.011, f"unexpected mass difference: {largest} MeV"
        print(f"PASS: {len(expected):,} DZ31 predictions; max |Delta| = {largest:.3f} MeV")


if __name__ == "__main__":
    main()
