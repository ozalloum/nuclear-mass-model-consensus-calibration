#!/usr/bin/env python3
"""Audit archived AME standardization against the official AMDC fixed-width files.

Independent of the original repository's scoring and processing functions.
Reads the exact ASCII sources downloaded from https://www-nds.iaea.org/amdc/.
Preserves all original files and emits a comparison report and recreated CSVs.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1] / "nuclear_mass_repo"
RAW = HERE / "official_inputs"
OUT = HERE / "recreated"

INPUTS = {
    2012: ("ame2012_mass.mas12", "https://www-nds.iaea.org/amdc/ame2012/mass.mas12"),
    2016: ("ame2016_mass16.txt", "https://www-nds.iaea.org/amdc/ame2016/mass16.txt"),
    2020: ("ame2020_mass_1.mas20.txt", "https://www-nds.iaea.org/amdc/ame2020/mass_1.mas20.txt"),
}


def get_number(piece: str):
    # The official Fortran files replace a decimal point by '#' when the
    # quantity is estimated rather than a directly evaluated datum.
    piece = piece.strip().replace("#", ".")
    if not piece or "*" in piece:
        return np.nan
    return float(piece)


def parse_year(year: int):
    filename, source_url = INPUTS[year]
    path = RAW / filename
    if not path.is_file():
        raise FileNotFoundError(f"Missing official source: {path}. Download {source_url}")
    contents = path.read_bytes()
    lines = contents.decode("ascii").splitlines()
    # AME2020 increased the precision and changed all trailing column widths.
    mass_width, unc_width, be_width = (14, 12, 13) if year == 2020 else (13, 11, 11)
    # Fortran column layout common prefix:
    # a1,i3,i5,i5,i5,1x,a3,a4,1x,[mass],[unc],[BE]...
    mass_start = 28
    unc_start = mass_start + mass_width
    be_start = unc_start + unc_width

    records = []
    for lineno, line in enumerate(lines, start=1):
        try:
            n = int(line[4:9])
            z = int(line[9:14])
            a = int(line[14:19])
        except (ValueError, IndexError):
            continue
        if n < 0 or z < 0 or a != n + z or a < 1:
            continue
        element = line[20:23].strip()
        if not element:
            continue
        mass_piece = line[mass_start:unc_start]
        unc_piece = line[unc_start:be_start]
        be_piece = line[be_start:be_start+be_width]
        try:
            mass_kev = get_number(mass_piece)
            unc_kev = get_number(unc_piece)
        except ValueError as exc:
            raise ValueError(f"Invalid AME{year} record at line {lineno}: {line!r}") from exc
        mass_est = "#" in mass_piece
        be_est = "#" in be_piece
        broad = n >= 8 and z >= 8 and not mass_est and np.isfinite(mass_kev)
        primary = broad and np.isfinite(unc_kev) and unc_kev < 100.0
        records.append({
            "vintage": year, "N": n, "Z": z, "A": a, "element": element,
            "mass_excess_MeV": mass_kev / 1000.,
            "mass_excess_unc_keV": unc_kev,
            "mass_estimated": mass_est, "be_estimated": be_est,
            "primary_eligible": bool(primary), "broad_eligible": bool(broad),
        })
    df = pd.DataFrame.from_records(records)
    if df.duplicated(["N", "Z"]).any():
        raise AssertionError(f"AME{year}: duplicate (N,Z) records")
    return df, {
        "source_file": filename,
        "source_url": source_url,
        "source_sha256": hashlib.sha256(contents).hexdigest(),
        "raw_lines": len(lines),
    }


def audit_year(year: int):
    recreated, meta = parse_year(year)
    archived = pd.read_csv(REPO / f"data/processed/ame{year}_mass_standardized.csv")
    key = ["N", "Z"]
    actual = recreated.set_index(key).sort_index()
    original = archived.set_index(key).sort_index()
    if actual.shape != original.shape or not actual.index.equals(original.index):
        raise AssertionError(
            f"AME{year}: key mismatch; raw {actual.shape}, archive {original.shape}"
        )
    count = len(actual)
    categorical = ("vintage", "A", "element", "mass_estimated",
                   "be_estimated", "primary_eligible", "broad_eligible")
    for col in categorical:
        left, right = actual[col], original[col]
        if not left.equals(right):
            idx = left.ne(right)
            ex = pd.DataFrame({"raw": left[idx], "archive": right[idx]}).head(5)
            raise AssertionError(f"AME{year}: {col} differs in {idx.sum()} rows:\n{ex}")
    differences = {}
    for col in ("mass_excess_MeV", "mass_excess_unc_keV"):
        left, right = actual[col], original[col]
        mismatched_na = left.isna().ne(right.isna())
        if mismatched_na.any():
            raise AssertionError(f"AME{year}: null mismatches in {col}")
        delta = (left-right).abs()
        max_delta = float(delta.max())
        differences[col] = max_delta
        if max_delta > 5e-10:
            bad = delta.nlargest(5)
            raise AssertionError(f"AME{year}: {col} differs, largest:\n{bad}")
    OUT.mkdir(exist_ok=True)
    out_csv = OUT / f"ame{year}_recreated_from_official.csv"
    recreated.to_csv(out_csv, index=False)
    return {
        **meta,
        "year": year, "rows_verified": count,
        "primary_eligible": int(actual.primary_eligible.sum()),
        "broad_eligible": int(actual.broad_eligible.sum()),
        "maximum_numeric_difference": differences,
        "verification": "exact eligibility/flags and numeric equality within 5e-10",
        "output_file": str(out_csv.relative_to(HERE)),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--report-only", action="store_true",
                        help="Only read existing report; do not reparse raw files")
    args = parser.parse_args()
    report_file = HERE / "ame_source_audit.json"
    if args.report_only:
        print(report_file.read_text())
        return
    results = [audit_year(y) for y in (2012, 2016, 2020)]
    report_file.write_text(json.dumps({"ame_audit": results}, indent=2)+"\n")
    for row in results:
        print(f"AME{row['year']}: PASS, {row['rows_verified']} records; "
              f"primary={row['primary_eligible']}, broad={row['broad_eligible']}, "
              f"source SHA-256 {row['source_sha256'][:16]}...")


if __name__ == "__main__":
    main()
