#!/usr/bin/env python3
"""Update only calcium results from original AME/model data and Coraggio Table II.

The 10,000-draw statistical bootstrap and the other six figures are untouched.
"""
from __future__ import annotations

import pandas as pd

from audit_analysis import FIGURES, MODELS, TABLES, calcium_table, plot_calcium
from gsm_comparison import write_gsm_comparison


def main() -> None:
    ca = calcium_table()
    assert ca.A.tolist() == list(range(48, 61, 2))
    assert int(ca.AME2020_S2n_MeV.notna().sum()) == 5
    ca.to_csv(TABLES / "calcium_global_model_S2n.csv", index=False)
    plot_calcium(ca, FIGURES / "FigR_Calcium_global_S2n.pdf")

    measured = ca.dropna(subset=["AME2020_S2n_MeV"]).copy()
    for model in [*MODELS, "Coraggio2020"]:
        measured[f"{model}_absolute_error_MeV"] = (
            measured[f"{model}_S2n_MeV"] - measured.AME2020_S2n_MeV
        ).abs()
    measured.to_csv(TABLES / "calcium_shell_model_comparison.csv", index=False)
    write_gsm_comparison(ca)
    print("PASS: calcium curves, matched-isotope GSM comparison and extraction sensitivity regenerated")
    for model in [*MODELS, "Coraggio2020"]:
        print(f"{model}: MAE={measured[f'{model}_absolute_error_MeV'].mean():.3f} MeV (n=5)")


if __name__ == "__main__":
    main()
