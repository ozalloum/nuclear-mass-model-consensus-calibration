Checks completed on 3 November 2026.
REPRODUCTION_RESULT.json and logs/ record the completed ten-step numerical run.
Its input-manifest count describes that run, before public packaging records
and the identified manuscript were added. Log prefixes containing the local
workspace path are replaced with <reproduction-output>; numerical output is unchanged.
External_Source_Checks.json records the separately run primary-source checks.
independent_check.json records 158 independent point checks and 1,225 printed
numeric values across all 14 supplement tables. Repeat from public_release/:
python validation_2026_11_03/verify_reviewed_tables.py --code-data . --supplement revision_work/submission/JPhysG_106072_Supplement.tex --report ../new_table_check.json
No fresh Fortran compilation was performed in this review.
