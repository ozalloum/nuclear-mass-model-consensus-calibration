from pathlib import Path
import re,json,math,argparse
import numpy as np,pandas as pd
from scipy.stats import spearmanr,norm
root=Path(__file__).resolve().parent
cli=argparse.ArgumentParser(description='Independent numerical and printed-table checks for JPhysG-106072.')
cli.add_argument('--code-data',type=Path,default=root/'code_data')
cli.add_argument('--supplement',type=Path,default=root/'edited/Supplement/JPhysG_106072_Supplement.tex')
cli.add_argument('--report',type=Path,default=root/'independent_check.json')
args=cli.parse_args()
base=args.code_data; repo=base/'nuclear_mass_repo'; tab=base/'revision_work/tables'
models=['FRDM2012','HFB27','DZ31','WS4']
checks=[]; cohorts={}
def same(name,a,b,tol=1e-10):
 assert np.allclose(a,b,atol=tol,rtol=0,equal_nan=True),(name,a,b)
 checks.append(name)
for start,end,prefix in [(2012,2016,'dev'),(2016,2020,'confirm')]:
 old=pd.read_csv(repo/f'data/processed/ame{start}_mass_standardized.csv').set_index(['N','Z'])
 new=pd.read_csv(repo/f'data/processed/ame{end}_mass_standardized.csv').set_index(['N','Z'])
 # Rebuild new measured membership from the AME tables, independently of membership CSVs.
 oldkeys=set(old.index[old.broad_eligible]); g=new[new.broad_eligible & ~new.index.isin(oldkeys)].copy()
 for m in models:
  mdf=pd.read_csv(repo/f'data/standardized_models/{m}.csv').set_index(['N','Z'])
  g[m]=mdf.mass_excess_MeV
 g=g.dropna(subset=models).reset_index()
 for pop in ['primary','broad']:
  c=g[g.primary_eligible].copy() if pop=='primary' else g.copy()
  x=c[models].to_numpy(); c['D']=np.sqrt(((x-x.mean(1)[:,None])**2).sum(1)/3)
  c['E']=abs(x.mean(1)-c.mass_excess_MeV)
  c['near']=((abs(c.N.to_numpy()[:,None]-np.array([20,28,50,82,126]))<=2).any(1) |
             (abs(c.Z.to_numpy()[:,None]-np.array([20,28,50,82]))<=2).any(1))
  cohorts[prefix+'_'+pop]=c
metrics=pd.read_csv(tab/'cohort_metrics.csv').set_index('cohort')
dev=cohorts['dev_primary']; k=np.sqrt(np.sum(dev.E**2)/np.sum(dev.D**2)); const=np.sqrt(np.mean(dev.E**2))
for name,c in cohorts.items():
 r=metrics.loc[name]; err=c.E.to_numpy(); d=c.D.to_numpy(); rho,p=spearmanr(d,err)
 for field,v in {'n':len(c),'n_Z_chains':c.Z.nunique(),'rho':rho,'spearman_p':p,'MAE_MeV':err.mean(),
 'mean_D_MeV':d.mean(),'max_E_MeV':err.max(),'k_RMSE_over_RMSD':np.linalg.norm(err)/np.linalg.norm(d),
 'cover_D':sum(err<=d),'cover_2D':sum(err<=2*d),'near_magic_n':sum(c.near),
 'near_magic_MAE':c.loc[c.near,'E'].mean(),'elsewhere_MAE':c.loc[~c.near,'E'].mean(),
 'fcA':sum((d<=.25)&(err>=1)),'fcB':sum((d<=.23833366300035547)&(err>=.3412442500000008)),
 'cover_dev90':np.mean(err<=norm.ppf(.95)*k*d),'cover_dev95':np.mean(err<=norm.ppf(.975)*k*d)}.items(): same(name+'/'+field,v,r[field])
 for label,scale in [('crps_scaled_dev',k*d),('crps_fixed_dev',np.full(len(c),const))]:
  z=err/scale; crps=np.mean(scale*(z*(2*norm.cdf(z)-1)+2*norm.pdf(z)-1/math.sqrt(math.pi)))
  same(name+'/'+label,crps,r[label])
 # Direct model omission calculation.
 loo=pd.read_csv(tab/'leave_one_model_out.csv'); loo=loo[loo.cohort==name].set_index('omitted_model')
 for m in models:
  a=c[[v for v in models if v!=m]].to_numpy(); e=abs(a.mean(1)-c.mass_excess_MeV); s=a.std(1,ddof=1); rr,pp=spearmanr(s,e)
  for field,v in {'MAE_MeV':e.mean(),'rho_D_E':rr,'rho_p':pp,'coverage_D':np.mean(e<=s),'coverage_2D':np.mean(e<=2*s)}.items():same(name+'/omit '+m+'/'+field,v,loo.loc[m,field])
c=cohorts['confirm_primary']; X=np.column_stack([np.ones(len(c)),c.D,c.near.astype(int)]); y=c.E.to_numpy()
inv=np.linalg.inv(X.T@X); beta=inv@X.T@y; h=np.sum((X@inv)*X,axis=1); u=y-X@beta
cov=inv@X.T@np.diag((u/(1-h))**2)@X@inv
reg=pd.read_csv(tab/'near_magic_leave_one_out.csv').iloc[0]
same('shell regression coefficients',beta,reg[['intercept','slope_D','near_magic_effect']].to_numpy(float))
same('shell HC3 SE',math.sqrt(cov[2,2]),reg.effect_SE_HC3)
# Reconcile every numerical cell of all 14 printed supplementary tables.
tex=args.supplement.read_text(encoding='utf-8')
tables={}
for block in re.findall(r'\\begin\{longtable\}(.*?)\\end\{longtable\}',tex,re.S):
 label=re.search(r'\\label\{([^}]+)\}',block).group(1)
 body=block.split('\\endhead',1)[1].split('\\bottomrule',1)[0]
 tables[label]=[[v.strip() for v in line.split('&')] for line in body.splitlines() if '&' in line]
numeric_checks=0; table_report=[]
def validate(label,rows):
 global numeric_checks
 actual=tables[label]; assert len(actual)==len(rows),(label,len(actual),len(rows))
 for i,(cells,expected) in enumerate(zip(actual,rows)):
  assert len(cells)==len(expected),(label,i,cells,expected)
  for j,(cell,value) in enumerate(zip(cells,expected)):
   if value is None: continue
   if isinstance(value,str):
    assert cell.replace('\\\\','').strip()==value,(label,i,j,cell,value)
    continue
   vals=list(value) if isinstance(value,(tuple,list)) else [value]
   toks=re.findall(r'[-+]?\d+(?:\.\d+)?',cell)
   if len(vals)==1 and pd.isna(vals[0]): assert '---' in cell,(label,i,j,cell); continue
   assert len(toks)==len(vals),(label,i,j,cell,vals)
   for tok,v in zip(toks,vals):
    if '<' in cell: assert v<float(tok),(label,i,j,cell,v)
    else:
     tol=.500001*10**(-len(tok.split('.')[1])) if '.' in tok else 1e-10
     assert abs(float(tok)-v)<=tol,(label,i,j,cell,v)
    numeric_checks+=1
 table_report.append({'table':label,'rows':len(rows),'status':'PASS'})
ci=lambda r,p:[r[p+'_lo'],r[p+'_hi']]
met=metrics.reset_index()
validate('tab:main',[[None,r.n,r.rho,r.spearman_p,ci(r,'rho_Zblock_ci95'),r.MAE_MeV,r.k_RMSE_over_RMSD,[r.cover_D,r.n],[r.cover_2D,r.n]] for _,r in met.iterrows()])
validate('tab:coverage',[[None,r.cover_D_frac,ci(r,'cover_D_wilson95'),r.cover_2D_frac,ci(r,'cover_2D_wilson95'),ci(r,'k_Zblock_ci95'),r.crps_scaled_dev,r.crps_fixed_dev] for _,r in met.iterrows()])
b=pd.read_csv(tab/'cohort_Zblock_coverage_MAE_v9.csv')
validate('tab:chaincoverage',[[None,r.n_Z_chains,ci(r,'MAE_MeV_Zblock_ci95'),ci(r,'cover_D_frac_Zblock_ci95'),ci(r,'cover_2D_frac_Zblock_ci95')] for _,r in b.iterrows()])
q=pd.read_csv(tab/'quintiles_with_bootstrap.csv')
validate('tab:quints',[[None,r.bin,r.n,r.mean_E,ci(r,'meanE_ci68'),ci(r,'meanE_ci95'),r.RMS_E,r.RMS_D] for _,r in q.iterrows()])
n=pd.read_csv(tab/'confirmation_71_nuclei.csv')
validate('tab:cases',[[str(int(r.A))+r.element,r.N,r.Z,'Y' if r.new_primary_eligible else 'N',r.mass_excess_unc_keV,r.D,r.E,r.near_magic,r.d1,r.d2] for _,r in n.iterrows()])
validate('tab:shellbootstrap',[[None,metrics.loc[r.cohort,'near_magic_n'],r.near_minus_else_MAE_MeV,ci(r,'near_minus_else_MAE_MeV_Zblock_ci95')] for _,r in b.iterrows()])
loo=pd.read_csv(tab/'leave_one_model_out.csv')
validate('tab:loo',[[None,r.omitted_model,r.n,r.MAE_MeV,r.rho_D_E,r.rho_p,r.coverage_D,r.coverage_2D] for _,r in loo.iterrows()])
reg=pd.read_csv(tab/'near_magic_leave_one_out.csv')
validate('tab:shell',[[r.omitted,r.n,r.n_near,r.intercept,r.slope_D,r.near_magic_effect,r.effect_SE_HC3] for _,r in reg.iterrows()])
chart=pd.read_csv(tab/'chart_condition_associations.csv')
validate('tab:chart',[[None,r.covariate,r.target,r.n,r.rho,r.p] for _,r in chart[chart.covariate!='d2_tercile'].iterrows()])
validate('tab:distance',[[None,r.target,r.n,r.MAE_MeV] for _,r in chart[chart.covariate=='d2_tercile'].iterrows()])
iso=pd.read_csv(repo/'tables/Table4_Conditional_False_Consensus.csv'); iso=iso[iso.variable=='isospin_asymmetry']
validate('tab:isospin',[[None,None,r.n,r.mean_E_MeV] for _,r in iso.iterrows()])
cal=pd.read_csv(tab/'calcium_global_model_S2n.csv')
validate('tab:calcium',[[str(int(r.A))+'Ca',r.N,r.AME2020_S2n_MeV if r.measured_broad else np.nan,r.approx_S2n_unc_MeV if r.measured_broad else np.nan,*[r[m+'_S2n_MeV'] for m in models],r.Coraggio2020_S2n_MeV] for _,r in cal.iterrows()])
gsm=pd.read_csv(base/'revision_work/raw_source_audit/gsm_vector/Li2020_Fig2b_GSM_digitized.csv')
validate('tab:gsmvalues',[[r.A,r.A-20,r.S2n_GSM_core48_MeV,r.S2n_GSM_core54_MeV] for _,r in gsm.iterrows()])
gm=pd.read_csv(tab/'calcium_GSM_matched_metrics.csv')
validate('tab:gsmmatched',[[None,r.MAE_MeV,r.RMSE_MeV,r.bias_MeV] for _,r in gm.iterrows()])
assert len(table_report)==len(tables)==14
report={'status':'PASS','date':'2026-11-03','independent_point_checks':len(checks),'numeric_values_checked_in_supplement':numeric_checks,'tables':table_report,'check_names':checks}
args.report.write_text(json.dumps(report,indent=2))
print('PASS:',len(checks),'independent point checks;',numeric_checks,'numeric values in all 14 supplement tables')
