The two identified sources are in revision_work/submission/.
Run BUILD_IOP.sh or BUILD_IOP.bat from this package. The supplied IOP class and
figure paths are retained. Build files are written to build/ and do not overwrite
the deposited PDFs or checksums. Both documents require a standard pdflatex
installation with their listed packages. Three passes resolve references.
