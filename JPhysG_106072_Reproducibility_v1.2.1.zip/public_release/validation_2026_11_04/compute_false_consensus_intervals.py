"""Recalculate Supplement S9/Table 15 from the preserved AME/model tables.

No supplied analysis module is imported. Intervals are descriptive binomial
Wilson bounds; they do not adjust for isotopic-chain dependence.
Run from public_release: python validation_2026_11_04/compute_false_consensus_intervals.py
"""
from pathlib import Path
import argparse,csv,json,math,statistics
import numpy as np
import pandas as pd

def calculate(base):
    repo=base/'nuclear_mass_repo'
    config=json.loads((repo/'stage2a_development/FROZEN_CONFIGURATION_PRE_CONFIRMATION.json').read_text())
    names=['FRDM2012','HFB27','DZ31','WS4']
    ame={y:pd.read_csv(repo/f'data/processed/ame{y}_mass_standardized.csv').set_index(['N','Z']) for y in [2012,2016,2020]}
    models={n:pd.read_csv(repo/f'data/standardized_models/{n}.csv').set_index(['N','Z']).mass_excess_MeV for n in names}
    out=[]
    for old,new,prefix in [(2012,2016,'dev'),(2016,2020,'conf')]:
        earlier=ame[old];measured=set(earlier.index[np.isfinite(earlier.mass_excess_MeV)&~earlier.mass_estimated])
        for kind in ['primary','broad']:
            cohort=f'{prefix}_{kind}'
            current=ame[new]
            # Eligibility flags were independently checked against the archived
            # official AME inputs in the recorded source audit.
            d=current.loc[current[kind+'_eligible']].copy()
            d=d.loc[[i not in measured for i in d.index]]
            for n in names:d=d.join(models[n].rename(n))
            assert d[names].notna().all().all()
            assert len(d)=={'dev_primary':32,'dev_broad':58,'conf_primary':51,'conf_broad':71}[cohort]
            p=d[names].to_numpy();spread=p.std(axis=1,ddof=1);error=np.abs(p.mean(axis=1)-d.mass_excess_MeV.to_numpy())
            low=spread<=config['fc_A']['D_max_MeV']
            a=int(np.sum(low & (error>=config['fc_A']['E_min_MeV'])))
            b=int(np.sum((spread<=config['fc_B']['D_max_MeV'])&(error>=config['fc_B']['E_min_MeV'])))
            for event,k,n in [('FC-A',a,len(d)),('FC-B',b,len(d)),('FC-A_given_D<=0.25',a,int(low.sum()))]:
                rate=k/n;z=statistics.NormalDist().inv_cdf(.975);z2=z*z
                center=(rate+z2/(2*n))/(1+z2/n)
                half=z*math.sqrt(rate*(1-rate)/n+z2/(4*n*n))/(1+z2/n)
                out.append(dict(cohort=cohort,event=event,count=k,denominator=n,rate=rate,wilson_low=max(0,center-half),wilson_high=min(1,center+half)))
    return out

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--package-root',type=Path,default=Path(__file__).resolve().parent.parent);ap.add_argument('--reference',type=Path,default=Path(__file__).with_name('false_consensus_intervals.csv'));ap.add_argument('--output',type=Path);a=ap.parse_args()
    rows=calculate(a.package_root)
    if a.reference.exists():
        reference=list(csv.DictReader(a.reference.open(newline='')));assert len(reference)==len(rows)==12
        for r,s in zip(rows,reference):
            for col,v in r.items():
                if isinstance(v,str):assert v==s[col],(col,r,s)
                else:assert abs(v-float(s[col]))<1e-12,(col,r,s)
    if a.output:
        with a.output.open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    print(json.dumps({'status':'PASS','cohorts':4,'event_rows':12,'table':15,'source':'preserved AME and four-model tables','interval_type':'descriptive Wilson 95%, no chain adjustment','rows':rows},indent=2))
