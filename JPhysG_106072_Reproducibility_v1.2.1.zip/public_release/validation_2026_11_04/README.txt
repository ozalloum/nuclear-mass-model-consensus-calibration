Final checks for the 4 November 2026 submission.
Integrity counts in the reproduction record describe the tested candidate,
before this run's report and logs were added to the final archive.
The four historical cohorts and their scientific interpretation are unchanged.
Supplement S9/Table 15 adds previously omitted event counts and descriptive Wilson
95% bounds, including the separate conditional low-spread denominators. These
binomial intervals do not adjust for isotopic-chain dependence.

From the package root:
python validation_2026_11_04/compute_false_consensus_intervals.py
python validation_2026_11_04/verify_reviewed_tables.py --code-data . --supplement revision_work/submission/JPhysG_106072_Supplement.tex --report ../new_table_check.json
For the author-omitted package substitute JPhysG_106072_Supplement_Anonymous.tex.

printed_table_checks.json records 158 independent point checks and 1,273 numeric
values across all 15 supplement tables. Original 43 scientific CSVs and 19 frozen
inputs are byte-identical to the previous reviewed package. The new event CSV
is recalculated separately from the AME/model tables; no analysis module is imported.
The complete 11-step reproduction passed on 4 November 2026, comparing the 43 original scientific CSVs plus the new event CSV. Its report and logs are included.
No fresh Fortran compilation or online source-PDF check is claimed.
