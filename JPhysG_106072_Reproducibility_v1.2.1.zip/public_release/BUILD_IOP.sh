#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
mkdir -p build
build_dir="$(pwd)/build"
cd revision_work/submission
for document in JPhysG_106072_Revised JPhysG_106072_Supplement; do
  for pass in 1 2 3; do
    pdflatex -interaction=nonstopmode -halt-on-error -output-directory="$build_dir" "$document.tex"
  done
done
