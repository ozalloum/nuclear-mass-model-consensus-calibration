# Packaging repair — 3 November 2026

The previous scientific ZIP omitted the raw DZ31 massex.out file required by
its verification workflow. This package restores the original file, recovered
unchanged from the earlier supplied code-and-data archive: 957,375 bytes,
21,275 rows, SHA-256
32ad383091ef86d4ed5af28b2e4ad4caab5cee6bb2194ebae1cb83d0431ffb61.

The manuscript and supplement now match the reviewed clean PDFs and LaTeX
sources. The scientific conclusion, seven submission figures, 43 scientific
CSVs and 19 frozen input/configuration files are unchanged. Stale generated
LaTeX/cache files are omitted and the integrity manifest is regenerated.

The runner explicitly requires essential reproduction inputs. The Coraggio
validator explicitly decodes UTF-8 output on Windows; scientific calculations
are unchanged. Original dependency pins and historical validation evidence are
retained. requirements.review-tested.txt records the environment actually used
for the successful ten-step run. Current checks are separately dated in
validation_2026_11_03/. A fresh Fortran compilation was not performed.
