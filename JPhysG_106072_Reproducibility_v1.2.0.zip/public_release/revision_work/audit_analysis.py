#!/usr/bin/env python3
"""Independent analysis for JPhysG-106072, using v1.0.0's standardized data.

No original scoring, plotting, or verification functions are imported.  This
script rebuilds development/confirmation cohorts from AME membership tables,
joins the four mass-model tables, computes predeclared broad sensitivity, and
produces tables/figures suitable for a major revision.  Independent AME and
RIPL-4 raw-source checks are supplied separately under raw_source_audit/.
"""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.spatial import cKDTree
from scipy.stats import norm, rankdata, spearmanr, t as student_t


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent / "nuclear_mass_repo"
FIGURES = HERE / "figures"
TABLES = HERE / "tables"
MODELS = ("FRDM2012", "HFB27", "DZ31", "WS4")
NEUTRON_MASS_EXCESS = 8.0713181
SEED = 42
BOOT = 10000


def save_figure(fig, path):
    """Export the same scientifically identical axes to vector PDF and 300-dpi PNG."""
    fig.savefig(path, bbox_inches="tight")
    fig.savefig(path.with_suffix(".png"), dpi=300, bbox_inches="tight")
    plt.close(fig)


def percentile_ci(values: np.ndarray, level: float = .95) -> tuple[float, float]:
    q = (1 - level) / 2
    return tuple(np.quantile(np.asarray(values, dtype=float), [q, 1 - q]))


def wilson(numer: int, denom: int, z: float = 1.959963984540054) -> tuple[float, float]:
    p = numer / denom
    center = (p + z * z / (2 * denom)) / (1 + z * z / denom)
    half = z * np.sqrt(p * (1 - p) / denom + z * z / (4 * denom * denom)) / (1 + z * z / denom)
    return max(0., center - half), min(1., center + half)


def ci_boot(x: np.ndarray, fn, seed: int = SEED, reps: int = BOOT, level: float = .95):
    x = np.asarray(x, float)
    if len(x) < 2:
        return float("nan"), float("nan")
    rng = np.random.default_rng(seed)
    indices = rng.integers(0, len(x), size=(reps, len(x)))
    return percentile_ci(fn(x[indices], axis=1), level)


def rho_boot(g: pd.DataFrame, cluster: bool = False):
    d = g["D"].to_numpy(float)
    e = g["E"].to_numpy(float)
    if not cluster:
        rng = np.random.default_rng(SEED)
        sample = rng.integers(0, len(g), size=(BOOT, len(g)))
        ranks_d = rankdata(d[sample], axis=1)
        ranks_e = rankdata(e[sample], axis=1)
        ranks_d -= ranks_d.mean(axis=1, keepdims=True)
        ranks_e -= ranks_e.mean(axis=1, keepdims=True)
        r = np.sum(ranks_d * ranks_e, axis=1) / np.sqrt(np.sum(ranks_d**2, axis=1) * np.sum(ranks_e**2, axis=1))
        return percentile_ci(r)
    chains = [(group.D.to_numpy(float), group.E.to_numpy(float)) for _, group in g.groupby("Z")]
    rng = np.random.default_rng(SEED)
    vals = []
    for _ in range(BOOT):
        pieces = [chains[i] for i in rng.integers(0, len(chains), len(chains))]
        sd = np.concatenate([p[0] for p in pieces])
        se = np.concatenate([p[1] for p in pieces])
        rd = rankdata(sd)
        re = rankdata(se)
        vals.append(float(np.corrcoef(rd, re)[0,1]))
    return percentile_ci(np.asarray(vals))


def ratio_boot(g: pd.DataFrame, cluster: bool = False):
    d = g.D.to_numpy(float)
    e = g.E.to_numpy(float)
    if not cluster:
        rng = np.random.default_rng(SEED + 11)
        ix = rng.integers(0, len(g), size=(BOOT, len(g)))
        return percentile_ci(np.sqrt(np.sum(e[ix]**2, axis=1) / np.sum(d[ix]**2, axis=1)))
    chains = [(group.D.to_numpy(float),group.E.to_numpy(float)) for _, group in g.groupby("Z")]
    rng = np.random.default_rng(SEED + 11)
    vals = []
    for _ in range(BOOT):
        pieces = [chains[i] for i in rng.integers(0, len(chains), len(chains))]
        sd = np.concatenate([p[0] for p in pieces])
        se = np.concatenate([p[1] for p in pieces])
        vals.append(np.sqrt(np.sum(se**2) / np.sum(sd**2)))
    return percentile_ci(np.asarray(vals))


def historical_cohort(first: int, second: int) -> pd.DataFrame:
    h = pd.read_csv(ROOT / f"data/processed/historical_{first}_to_{second}_membership.csv")
    h = h.loc[h.label.eq("new") & h.new_broad_eligible].copy()
    exp = pd.read_csv(ROOT / f"data/processed/ame{second}_mass_standardized.csv")
    h = h.merge(
        exp[["N", "Z", "mass_excess_MeV", "mass_excess_unc_keV"]],
        on=["N", "Z"], validate="one_to_one"
    )
    for m in MODELS:
        t = pd.read_csv(ROOT / f"data/standardized_models/{m}.csv")
        h = h.merge(t[["N", "Z", "mass_excess_MeV"]].rename(columns={"mass_excess_MeV":m}),
                    on=["N", "Z"], validate="one_to_one", how="left")
    if not h[list(MODELS)].notna().all(axis=1).all():
        raise ValueError("Broad cohort contains an incomplete four-model case")
    h["center"] = h[list(MODELS)].mean(axis=1)
    h["D"] = h[list(MODELS)].std(axis=1, ddof=1)
    h["E"] = (h.center - h.mass_excess_MeV).abs()
    h["signed_error"] = h.center - h.mass_excess_MeV
    h["median_error"] = (h[list(MODELS)].median(axis=1) - h.mass_excess_MeV).abs()
    for m in MODELS:
        h[f"err_{m}"] = (h[m] - h.mass_excess_MeV).abs()
    n_magic = (20, 28, 50, 82, 126)
    z_magic = (20, 28, 50, 82)
    h["dN_magic"] = h.N.map(lambda v: min(abs(v - q) for q in n_magic))
    h["dZ_magic"] = h.Z.map(lambda v: min(abs(v - q) for q in z_magic))
    h["near_magic"] = (h.dN_magic.le(2) | h.dZ_magic.le(2)).astype(int)
    h["isospin"] = (h.N - h.Z) / h.A
    prior = pd.read_csv(ROOT / f"data/processed/ame{first}_mass_standardized.csv")
    prior = prior.loc[prior.primary_eligible, ["N", "Z"]]
    tree = cKDTree(prior[["N", "Z"]].to_numpy())
    h["d2"] = tree.query(h[["N", "Z"]].to_numpy(), k=1)[0]
    # The independent Manhattan distance check is small enough to broadcast.
    earlier = prior[["N", "Z"]].to_numpy(int)
    targets = h[["N", "Z"]].to_numpy(int)
    h["d1"] = [int(np.abs(earlier - p).sum(axis=1).min()) for p in targets]
    exp_valid = exp[exp.broad_eligible]
    neighbors = {(int(r.N), int(r.Z)): float(r.mass_excess_MeV) for r in exp_valid.itertuples()}
    for m in MODELS:
        t = pd.read_csv(ROOT / f"data/standardized_models/{m}.csv")
        values = {(int(r.N), int(r.Z)): float(r.mass_excess_MeV) for r in t.itertuples()}
        h[f"S2n_{m}"] = [values.get((int(n) - 2, int(z)), np.nan) + 2 * NEUTRON_MASS_EXCESS - values.get((int(n), int(z)), np.nan)
                          for n, z in zip(h.N, h.Z)]
    h["S2n_exp"] = [neighbors.get((int(n) - 2, int(z)), np.nan) + 2 * NEUTRON_MASS_EXCESS - val
                    for n, z, val in zip(h.N, h.Z, h.mass_excess_MeV)]
    h["D_S2n"] = h[[f"S2n_{m}" for m in MODELS]].std(axis=1, ddof=1)
    h["E_S2n"] = (h[[f"S2n_{m}" for m in MODELS]].mean(axis=1) - h.S2n_exp).abs()
    h["cohort"] = f"{first}-{second}"
    return h.sort_values(["Z", "N"]).reset_index(drop=True)


def crps_normal(signed_error: np.ndarray, sigma: np.ndarray):
    z = signed_error / sigma
    return sigma * (z * (2 * norm.cdf(z) - 1) + 2 * norm.pdf(z) - 1 / np.sqrt(np.pi))


def summarize(name: str, g: pd.DataFrame, ref_k: float, fixed_sig: float, cfg: dict):
    r, p = spearmanr(g.D, g.E)
    k = np.sqrt(np.sum(g.E**2) / np.sum(g.D**2))
    rho_ci = rho_boot(g)
    rho_chain_ci = rho_boot(g, True)
    k_ci = ratio_boot(g)
    k_chain_ci = ratio_boot(g, True)
    d, e = g.D.to_numpy(), g.E.to_numpy()
    numbers = {
        "cohort": name, "n": len(g), "n_Z_chains": g.Z.nunique(),
        "rho": r, "spearman_p": p,
        "rho_ci95_lo": rho_ci[0], "rho_ci95_hi": rho_ci[1],
        "rho_Zblock_ci95_lo": rho_chain_ci[0], "rho_Zblock_ci95_hi": rho_chain_ci[1],
        "MAE_MeV": np.mean(e), "mean_D_MeV": np.mean(d), "max_E_MeV": np.max(e),
        "k_RMSE_over_RMSD": k, "k_RMSE_ci95_lo": k_ci[0], "k_RMSE_ci95_hi": k_ci[1],
        "k_Zblock_ci95_lo": k_chain_ci[0], "k_Zblock_ci95_hi": k_chain_ci[1],
        "slope_E_on_D_origin": np.sum(e * d) / np.sum(d**2),
        "cover_D": int(np.sum(e <= d)), "cover_2D": int(np.sum(e <= 2*d)),
        "cover_D_frac": np.mean(e <= d), "cover_2D_frac": np.mean(e <= 2*d),
        "cover_D_expadd": int(np.sum(e <= np.hypot(d, g.mass_excess_unc_keV / 1000))),
        "cover_dev90": np.mean(e <= 1.644854 * ref_k * d),
        "cover_dev95": np.mean(e <= 1.959964 * ref_k * d),
        "crps_scaled_dev": float(np.mean(crps_normal(g.signed_error.to_numpy(), ref_k * d))),
        "crps_fixed_dev": float(np.mean(crps_normal(g.signed_error.to_numpy(), np.full(len(g), fixed_sig)))),
        "near_magic_n": int(g.near_magic.sum()),
        "near_magic_MAE": float(g.loc[g.near_magic.eq(1), "E"].mean()),
        "elsewhere_MAE": float(g.loc[g.near_magic.eq(0), "E"].mean()),
        "fcA": int(np.sum((d <= cfg["fc_A"]["D_max_MeV"]) &
                          (e >= cfg["fc_A"]["E_min_MeV"]))),
        "fcB": int(np.sum((d <= cfg["fc_B"]["D_max_MeV"]) &
                          (e >= cfg["fc_B"]["E_min_MeV"]))),
        "S2n_n": int(g.E_S2n.notna().sum()),
        "S2n_MAE": float(g.E_S2n.mean()),
    }
    for amount in ("D", "2D"):
        k1, n1 = numbers[f"cover_{amount}"], len(g)
        numbers[f"cover_{amount}_wilson95_lo"], numbers[f"cover_{amount}_wilson95_hi"] = wilson(k1, n1)
    return numbers


def quintile_table(name, g, cfg):
    edges = np.asarray(cfg["D_quintile_edges_MeV"])
    binning = pd.cut(g.D, bins=np.r_[-np.inf, edges[1:-1], np.inf], labels=[f"Q{j}" for j in range(1, 6)])
    rows = []
    for j in range(1, 6):
        vals = g.loc[binning.eq(f"Q{j}"), "E"].to_numpy(float)
        spread = g.loc[binning.eq(f"Q{j}"), "D"].to_numpy(float)
        row = {"cohort": name, "bin": f"Q{j}", "n": len(vals),
               "mean_E": float(np.mean(vals)) if len(vals) else np.nan,
               "median_E": float(np.median(vals)) if len(vals) else np.nan,
               "RMS_E": float(np.sqrt(np.mean(vals**2))) if len(vals) else np.nan,
               "RMS_D": float(np.sqrt(np.mean(spread**2))) if len(vals) else np.nan}
        for level in (.68, .95):
            row[f"meanE_ci{int(level*100)}_lo"], row[f"meanE_ci{int(level*100)}_hi"] = ci_boot(vals, np.mean, level=level)
        row["rmsE_ci95_lo"], row["rmsE_ci95_hi"] = ci_boot(vals, lambda x, axis: np.sqrt(np.mean(x**2, axis=axis)))
        rows.append(row)
    return pd.DataFrame(rows)


def conditions(name, g, cfg):
    out = []
    for key, x in [("d2", g.d2), ("d1", g.d1), ("isospin", g.isospin)]:
        for target in ("E", "D"):
            r, p = spearmanr(x, g[target])
            out.append({"cohort": name, "covariate": key, "target": target, "n": len(g), "rho": r, "p": p})
    edges = np.asarray(cfg["extrapolation_d2_tercile_edges"])
    assignment = pd.cut(g.d2, bins=np.r_[-np.inf, edges[1:-1], np.inf], labels=["near", "middle", "far"])
    for label in ("near", "middle", "far"):
        s = g.loc[assignment.eq(label)]
        out.append({"cohort": name, "covariate": "d2_tercile", "target": label, "n": len(s),
                    "rho": np.nan, "p": np.nan, "MAE_MeV": s.E.mean()})
    return pd.DataFrame(out)


def near_magic_loo(g):
    rows = []
    for omitted in [None] + list(g.loc[g.near_magic.eq(1)].index):
        sub = g.drop(index=omitted) if omitted is not None else g
        X = np.column_stack([np.ones(len(sub)), sub.D, sub.near_magic])
        b = np.linalg.lstsq(X, sub.E, rcond=None)[0]
        resid = sub.E.to_numpy() - X @ b
        h = np.sum(X * (X @ np.linalg.inv(X.T @ X)), axis=1)
        meat = X.T @ (X * (resid**2 / (1 - h)**2)[:, None])
        cov = np.linalg.inv(X.T @ X) @ meat @ np.linalg.inv(X.T @ X)
        rows.append({"omitted": "none" if omitted is None else f"{int(g.loc[omitted, 'A'])}{g.loc[omitted, 'element']}",
                     "n": len(sub), "n_near": int(sub.near_magic.sum()), "intercept": b[0],
                     "slope_D": b[1], "near_magic_effect": b[2], "effect_SE_HC3": np.sqrt(cov[2,2]),
                     "mean_near": sub.loc[sub.near_magic.eq(1), "E"].mean(),
                     "mean_other": sub.loc[sub.near_magic.eq(0), "E"].mean()})
    return pd.DataFrame(rows)


def calcium_table(exp_year: int = 2020):
    exp = pd.read_csv(ROOT / f"data/processed/ame{exp_year}_mass_standardized.csv")
    mass = {(int(r.N), int(r.Z)): (float(r.mass_excess_MeV), float(r.mass_excess_unc_keV), bool(r.broad_eligible), bool(r.primary_eligible)) for r in exp.itertuples()}
    model_mass = {}
    for m in MODELS:
        x = pd.read_csv(ROOT / f"data/standardized_models/{m}.csv")
        model_mass[m] = {(int(r.N), int(r.Z)): float(r.mass_excess_MeV) for r in x.itertuples()}
    rows = []
    for A in range(48, 61, 2):
        N, Z = A-20, 20
        d = {"A": A, "N": N, "Z": Z}
        val = mass.get((N,Z))
        prev = mass.get((N-2,Z))
        d["AME2020_S2n_MeV"] = prev[0] + 2*NEUTRON_MASS_EXCESS - val[0] if val and prev and val[2] and prev[2] else np.nan
        # Diagonal-error propagation only; the full AME covariance is not in
        # the archived standardized tables and is not being fabricated.
        d["approx_S2n_unc_MeV"] = np.hypot(val[1], prev[1])/1000 if val and prev and val[2] and prev[2] else np.nan
        d["target_unc_keV"] = val[1] if val else np.nan
        d["measured_broad"] = int(bool(val and val[2]))
        d["measured_primary"] = int(bool(val and val[3]))
        for m in MODELS:
            t = model_mass[m]
            d[f"{m}_S2n_MeV"] = t[(N-2,Z)] + 2*NEUTRON_MASS_EXCESS - t[(N,Z)]
        rows.append(d)
    ca = pd.DataFrame(rows)
    # Values from Table II of Coraggio et al., Phys. Rev. C 102, 054326
    # (2020), independently checked against the publisher-paper PDF.
    # This is a separately published shell-model calculation, never a
    # member of the original four-global-model consensus ensemble.
    regional_path = HERE / "raw_source_audit" / "coraggio2020_table_ii.csv"
    regional = pd.read_csv(regional_path)
    regional = regional[["A", "N", "Z", "Coraggio2020_S2n_MeV"]]
    ca = ca.merge(regional, on=["A", "N", "Z"], how="left", validate="one_to_one")
    if ca.Coraggio2020_S2n_MeV.isna().any():
        raise AssertionError("Missing Coraggio 2020 published calcium Table II row")
    gsm = pd.read_csv(HERE / "raw_source_audit/gsm_vector/Li2020_Fig2b_GSM_digitized.csv")
    ca = ca.merge(gsm[["A", "S2n_GSM_core48_MeV", "S2n_GSM_core54_MeV"]],
                  on="A", how="left", validate="one_to_one")
    return ca


def plot_reliability(quintiles, path):
    # Reviewer figure 5: numbered markers avoid overlapping long Q1-Q5/n
    # annotations and errors.  Exact counts remain in the manuscript caption
    # and supplementary quintile table.  A near-print-size canvas keeps the
    # labels legible when included at 145.35 mm in the IOP manuscript.
    fig, axs = plt.subplots(1, 2, figsize=(6.4, 2.7), sharex=True, sharey=True)
    for ax, cohort, color, panel in zip(
        axs,
        ["confirm_primary", "confirm_broad"],
        ["#16697a", "#c05a30"],
        ["(a)", "(b)"],
    ):
        s = quintiles.loc[quintiles.cohort.eq(cohort)].sort_values("RMS_D")
        ax.plot([0, 1.0], [0, 1.0], ls="--", lw=1.1, color=".52", zorder=1)
        ax.errorbar(
            s.RMS_D, s.RMS_E,
            yerr=np.vstack([s.RMS_E - s.rmsE_ci95_lo,
                            s.rmsE_ci95_hi - s.RMS_E]),
            fmt="none", ecolor=color, capsize=3.0,
            elinewidth=1.25, alpha=.9, zorder=2,
        )
        ax.scatter(s.RMS_D, s.RMS_E, s=150, color=color,
                   edgecolor="white", linewidth=.75, zorder=3)
        for r in s.itertuples():
            ax.text(r.RMS_D, r.RMS_E, str(r.bin).removeprefix("Q"),
                    ha="center", va="center", fontsize=10,
                    color="white", weight="bold", zorder=4)
        ax.set_xlim(0, 1.0)
        ax.set_ylim(0, 1.0)
        ax.set_xticks(np.linspace(0., 1., 6))
        ax.set_yticks(np.linspace(0., 1., 6))
        ax.text(.035, .965, panel, transform=ax.transAxes,
                ha="left", va="top", fontsize=11.5, weight="bold",
                bbox={"facecolor": "white", "edgecolor": "none", "alpha": .8, "pad": 1.5})
        ax.grid(alpha=.16, linewidth=.7)
        ax.tick_params(labelsize=10, pad=3)
    fig.supxlabel("RMS model spread (MeV)", fontsize=11.5, y=.025)
    fig.supylabel("RMS later absolute error (MeV)", fontsize=11.5, x=.018)
    fig.subplots_adjust(left=.12, right=.975, bottom=.23, top=.95, wspace=.18)
    save_figure(fig, path)


def plot_quintiles(quintiles, path):
    fig, ax = plt.subplots(figsize=(6.6,4.5))
    rows = [
        ("dev_primary", -0.15, "#303f9f", "o", "Development n=32"),
        ("confirm_primary", 0, "#00796b", "s", "Confirmation n=51"),
        ("confirm_broad", 0.15, "#c45120", "^", "Broad confirmation n=71"),
    ]
    for cohort, offset, color, marker, label in rows:
        s = quintiles.loc[quintiles.cohort.eq(cohort)]
        xx = np.arange(1,6)+offset
        yy = s.mean_E.to_numpy()
        yl = s.meanE_ci95_lo.to_numpy()
        yh = s.meanE_ci95_hi.to_numpy()
        ax.errorbar(xx,yy,yerr=np.vstack([yy-yl,yh-yy]),fmt=marker+"-",color=color,
                    linewidth=1.1,markersize=4,capsize=2,label=label)
    ax.set_xticks(range(1,6),[f"Q{n}" for n in range(1,6)])
    ax.set_xlabel("Development-defined spread bin (fixed edges)")
    ax.set_ylabel("Mean absolute error (MeV)")
    ax.legend(frameon=False,fontsize=8)
    ax.grid(alpha=.15)
    fig.tight_layout(); save_figure(fig,path)


def plot_scatter(g, path):
    fig, ax = plt.subplots(figsize=(6.0, 4.5))
    primary = g[g.new_primary_eligible]
    removed = g[~g.new_primary_eligible]
    ax.scatter(primary.D, primary.E, facecolors="none", edgecolors="#21618c", label=f"Primary (n={len(primary)})", s=35, marker="o")
    ax.scatter(removed.D, removed.E, color="#bb4f2c", label=f"Additional broad (n={len(removed)})", s=44, marker="^")
    x = np.linspace(0, max(g.D.max()*1.05, 1.2), 100)
    ax.plot(x,x,"--",color=".35",label="E = D")
    ax.axhline(1.0,color=".6",lw=.8,ls=":")
    ax.axvline(.25,color=".6",lw=.8,ls=":")
    for r in removed.nlargest(3, "E").itertuples():
        ax.annotate(f"{r.A}{r.element}", (r.D,r.E), xytext=(5,4), textcoords="offset points", fontsize=8)
    ax.set_xlabel("Four-model spread D (MeV)")
    ax.set_ylabel("Later absolute error E (MeV)")
    ax.legend(frameon=False, fontsize=8)
    ax.grid(alpha=.15); fig.tight_layout(); save_figure(fig,path)


def plot_chronology(dev_primary, con_primary, path):
    """Show evaluated memberships, without implying external registration."""
    earlier = pd.read_csv(ROOT / "data/processed/ame2012_mass_standardized.csv")
    earlier = earlier.loc[earlier.primary_eligible]
    fig, ax = plt.subplots(figsize=(7.5, 4.7))
    ax.scatter(earlier.N, earlier.Z, s=6.5, color="#c4c7c8", alpha=.65,
               linewidths=0, label=f"AME2012 eligible (n={len(earlier)})")
    ax.scatter(dev_primary.N, dev_primary.Z, s=36, facecolor="none",
               edgecolor="#116da1", linewidth=1.1,
               label=f"New by AME2016 (n={len(dev_primary)})")
    ax.scatter(con_primary.N, con_primary.Z, s=40, facecolor="none",
               edgecolor="#c25d1e", marker="s", linewidth=1.1,
               label=f"New by AME2020 (n={len(con_primary)})")
    ax.set_xlabel("Neutron number N")
    ax.set_ylabel("Proton number Z")
    ax.set_xlim(0, 178); ax.set_ylim(0, 122)
    ax.grid(alpha=.13)
    ax.legend(frameon=False, fontsize=8, loc="upper left")
    fig.tight_layout(); save_figure(fig,path)


def plot_nuclear_chart(con_primary, cfg, path):
    """Label observed FC-B cases without suggesting an FC-A detection."""
    ca, cb = cfg["fc_A"], cfg["fc_B"]
    fcb = (con_primary.D <= cb["D_max_MeV"]) & (con_primary.E >= cb["E_min_MeV"])
    fca = (con_primary.D <= ca["D_max_MeV"]) & (con_primary.E >= ca["E_min_MeV"])
    if fca.any() or fcb.sum() != 2:
        raise AssertionError("Unexpected false-consensus chart classification")
    low = (con_primary.D <= ca["D_max_MeV"]) & ~fcb
    other = ~low & ~fcb
    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    ax.scatter(con_primary.loc[other,"N"], con_primary.loc[other,"Z"],
               s=17, color="#b7b7b7", label="Other primary confirmation")
    ax.scatter(con_primary.loc[low,"N"], con_primary.loc[low,"Z"],
               s=54, facecolors="white", edgecolors="#009b87",
               linewidth=1.3, label="Low spread (D ≤ 0.25 MeV)")
    ax.scatter(con_primary.loc[fcb,"N"], con_primary.loc[fcb,"Z"],
               s=104, color="#c96b11", marker="X", label="FC-B sensitivity events")
    for r in con_primary.loc[fcb].itertuples():
        ax.annotate(f"{int(r.A)}{r.element}",(r.N,r.Z),
                    xytext=(6,3), textcoords="offset points", fontsize=9)
    ax.set_xlabel("Neutron number N")
    ax.set_ylabel("Proton number Z")
    ax.legend(frameon=False, fontsize=8, loc="upper left")
    ax.grid(alpha=.13)
    fig.tight_layout(); save_figure(fig,path)


def plot_calcium(ca, path):
    fig, axes = plt.subplots(1, 2, figsize=(8.8, 5.1), sharey=True)
    styles = {"FRDM2012":("#2171b5","o","-"), "HFB27":("#d95f02","s","--"),
              "DZ31":("#1b9e77","^","-."), "WS4":("#7b3294","D",":")}
    for m in MODELS:
        color, mark, line = styles[m]
        axes[0].plot(ca.A, ca[f"{m}_S2n_MeV"], color=color, marker=mark,
                     ls=line, lw=1.5, ms=4, label=m)
    ax=axes[1]
    ax.plot(ca.A, ca.Coraggio2020_S2n_MeV, color="#bc5090", ls="--", marker="p",
            ms=5, lw=1.5, label="Coraggio, Table II")
    ax.plot(ca.A, ca.S2n_GSM_core48_MeV, color="#d62728", ls="-", marker="v",
            mfc="white", ms=5, lw=1.4, label=r"GSM, $^{48}$Ca core")
    ax.plot(ca.A, ca.S2n_GSM_core54_MeV, color="#9467bd", ls="-.", marker="^",
            ms=5, lw=1.4, label=r"GSM, $^{54}$Ca core")
    x=ca.dropna(subset=["AME2020_S2n_MeV"])
    for ax,title in zip(axes,["(a) Global mass models", "(b) Regional shell models"]):
        ax.errorbar(x.A,x.AME2020_S2n_MeV,yerr=x.approx_S2n_unc_MeV,fmt="*",
                    ms=8,capsize=2,elinewidth=.9,color="black",label="AME2020",zorder=8)
        ax.axvline(54,ls=":",lw=.9,color=".55")
        ax.set(xlabel="Calcium mass number A",xlim=(47.5,60.5),ylim=(0,20),xticks=range(48,61,2))
        ax.set_title(title,fontsize=11)
        ax.tick_params(labelsize=10);ax.grid(alpha=.15)
        ax.legend(frameon=False,ncol=2,fontsize=9,loc="upper center",bbox_to_anchor=(.5,-.20),
                  handlelength=2.3,columnspacing=.9)
    axes[0].set_ylabel(r"Two-neutron separation energy $S_{2n}$ (MeV)",fontsize=11)
    fig.subplots_adjust(left=.085,right=.99,top=.90,bottom=.29,wspace=.13)
    save_figure(fig,path)


def plot_error_spread_cdf(primary, broad, path):
    """Check E/D against an explicitly counterfactual independent-model t3 law."""
    fig, ax = plt.subplots(figsize=(6.5, 4.5))
    for sample, color, label, linestyle in ((primary, "#16697a", "Primary (n=51)", "-"),
                                            (broad, "#bf562a", "Broad (n=71)", "-.")):
        ratio = np.sort((sample.E / sample.D).to_numpy(float))
        ax.step(np.r_[0., ratio], np.r_[0., np.arange(1, len(ratio)+1)/len(ratio)],
                where="post", color=color, linestyle=linestyle,
                linewidth=1.7, label=label)
    x = np.linspace(0., 4.0, 300)
    ax.plot(x, 2*student_t.cdf(2*x, df=3)-1, color="black", ls="--",
            linewidth=1.2, label="Four independent Gaussian models: |t3|/2")
    for cutoff in (1., 2.):
        ax.axvline(cutoff, color=".7", ls=":", linewidth=.8)
    ax.set_xlim(0, 4); ax.set_ylim(0, 1.02)
    ax.set_xlabel("Ratio: absolute prediction error / model spread (E/D)")
    ax.set_ylabel("Fraction with error/spread below threshold")
    ax.legend(frameon=False, fontsize=8, loc="lower right")
    ax.grid(alpha=.15)
    fig.tight_layout(); save_figure(fig,path)


def main():
    FIGURES.mkdir(parents=True, exist_ok=True)
    TABLES.mkdir(parents=True, exist_ok=True)
    cfg = json.loads((ROOT / "stage2a_development/FROZEN_CONFIGURATION_PRE_CONFIRMATION.json").read_text())
    dev_all = historical_cohort(2012, 2016)
    con_all = historical_cohort(2016, 2020)
    cohorts = {
        "dev_primary": dev_all.loc[dev_all.new_primary_eligible].copy(),
        "dev_broad": dev_all,
        "confirm_primary": con_all.loc[con_all.new_primary_eligible].copy(),
        "confirm_broad": con_all,
    }
    # Reconstruct the archived 51 cases with no reference to the stored scores.
    locked = pd.read_csv(ROOT / "stage2b_confirmation/CONFIRMATION_SCORED_LOCKED.csv")
    match = cohorts["confirm_primary"].merge(locked[["N","Z","D_MeV","E_MeV","E_S2n_MeV"]], on=["N","Z"])
    if len(match) != 51 or (match.D - match.D_MeV).abs().max() > 1e-10 or (match.E-match.E_MeV).abs().max() > 1e-10:
        raise AssertionError("Independent mass reconstruction does not match the locked scores")
    s2n_match = match.loc[match.E_S2n.notna() & match.E_S2n_MeV.notna()]
    if len(s2n_match) != 34 or (s2n_match.E_S2n-s2n_match.E_S2n_MeV).abs().max() > 1e-9:
        raise AssertionError("S2n reconstruction inconsistent with locked scores")
    dev = cohorts["dev_primary"]
    k_dev = float(np.sqrt(np.sum(dev.E**2)/np.sum(dev.D**2)))
    sigma_dev = float(np.sqrt(np.mean(dev.signed_error**2)))
    summaries = pd.DataFrame([summarize(name,g,k_dev,sigma_dev,cfg) for name,g in cohorts.items()])
    summaries.to_csv(TABLES/"cohort_metrics.csv",index=False)
    bins = pd.concat([quintile_table(name,g,cfg) for name,g in cohorts.items()],ignore_index=True)
    bins.to_csv(TABLES/"quintiles_with_bootstrap.csv",index=False)
    pd.concat([conditions(name,g,cfg) for name,g in cohorts.items()],ignore_index=True).to_csv(TABLES/"chart_condition_associations.csv",index=False)
    near_magic_loo(cohorts["confirm_primary"]).to_csv(TABLES/"near_magic_leave_one_out.csv",index=False)
    con_all[["A","element","N","Z","new_primary_eligible","mass_excess_MeV","mass_excess_unc_keV", "center", "D", "E", "near_magic", "d2", "d1", "isospin", "D_S2n", "E_S2n"]].to_csv(TABLES/"confirmation_71_nuclei.csv",index=False)
    # Model-level sensitivity results for both population definitions.
    loo_rows=[]
    for name,g in cohorts.items():
        for omit in MODELS:
            pred=g[[m for m in MODELS if m != omit]].mean(axis=1)
            err=np.abs(pred-g.mass_excess_MeV)
            dthree=g[[m for m in MODELS if m != omit]].std(axis=1,ddof=1)
            rank,p=spearmanr(dthree,err)
            loo_rows.append({"cohort":name,"omitted_model":omit,"n":len(g),
                             "MAE_MeV":float(np.mean(err)),"rho_D_E":rank,"rho_p":p,
                             "coverage_D":float(np.mean(err<=dthree)),"coverage_2D":float(np.mean(err<=2*dthree))})
    pd.DataFrame(loo_rows).to_csv(TABLES/"leave_one_model_out.csv",index=False)
    ca = calcium_table()
    ca.to_csv(TABLES/"calcium_global_model_S2n.csv",index=False)
    plot_reliability(bins,FIGURES/"FigR_RMS_reliability.pdf")
    plot_scatter(con_all,FIGURES/"FigR_Broad_scatter.pdf")
    plot_chronology(cohorts["dev_primary"],cohorts["confirm_primary"],FIGURES/"FigR_Chronology.pdf")
    plot_nuclear_chart(cohorts["confirm_primary"],cfg,FIGURES/"FigR_FalseConsensusChart.pdf")
    plot_quintiles(bins,FIGURES/"FigR_Quintiles_CI.pdf")
    plot_calcium(ca,FIGURES/"FigR_Calcium_global_S2n.pdf")
    plot_error_spread_cdf(cohorts["confirm_primary"],con_all,FIGURES/"FigR_Coverage_CDF.pdf")
    print("Independent cohort reconstructions: 2012->2016 broad",len(dev_all),"2016->2020 broad",len(con_all))
    print("Model and S2n crosschecks: PASS")
    print(summaries[["cohort","n","rho","spearman_p","rho_ci95_lo","rho_ci95_hi","rho_Zblock_ci95_lo","rho_Zblock_ci95_hi","MAE_MeV","k_RMSE_over_RMSD","cover_D","cover_2D","S2n_n","S2n_MAE"]].to_string(index=False,float_format=lambda x:f"{x:.4f}"))
    print("Leave-one-out shell effect: ")
    print(pd.read_csv(TABLES/"near_magic_leave_one_out.csv").to_string(index=False,float_format=lambda x:f"{x:.3f}"))


if __name__ == "__main__":
    main()
