#!/usr/bin/env python3
"""Verify transcribed calcium S2n values against Coraggio et al. (2020), Table II.

Source: Phys. Rev. C 102, 054326 (2020), Table II.
Download author manuscript PDF independently from:
https://www.osti.gov/servlets/purl/1851239
or the public author preprint (Table II, PDF page 6):
https://arxiv.org/pdf/2006.15196v2

Usage: python3 validate_coraggio_2020.py /path/to/Coraggio2020.pdf
Requires an installed `pdftotext` utility; the source paper is *not* redistributed.
"""

from __future__ import annotations

import argparse
from pathlib import Path
import re
import subprocess
import pandas as pd


TABLE = Path(__file__).resolve().parent / "coraggio2020_table_ii.csv"


def main() -> None:
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("paper_pdf", type=Path)
    args = cli.parse_args()
    paper_text = subprocess.run(["pdftotext", "-layout", str(args.paper_pdf), "-"],
                                check=True, text=True, capture_output=True).stdout
    source_calc = next(s for s in paper_text.splitlines() if "Calculated S2n" in s)
    source_exp = next(s for s in paper_text.splitlines() if "Experimental S2n" in s)
    numeric = lambda s: [float(x) for x in re.findall(r"(?<!\w)\d+\.\d+", s)]
    calculated = numeric(source_calc.split("Calculated S2n", 1)[1])
    published_exp = numeric(source_exp.split("Experimental S2n", 1)[1])
    archive = pd.read_csv(TABLE).sort_values("A").reset_index(drop=True)
    assert archive.A.tolist() == list(range(42, 71, 2))
    assert len(calculated) == len(archive) == 15
    assert len(published_exp) == 8
    for i, a in enumerate(archive.itertuples()):
        assert abs(a.Coraggio2020_S2n_MeV - calculated[i]) < 1e-9, (a.A, calculated[i])
        if i < len(published_exp):
            assert abs(a.Published_experimental_S2n_MeV - published_exp[i]) < 1e-9
    print("PASS: all 15 calculated and 8 published experimental Table II entries")


if __name__ == "__main__":
    main()
