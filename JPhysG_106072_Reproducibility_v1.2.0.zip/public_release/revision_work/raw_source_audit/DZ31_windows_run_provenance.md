# Official DZ31 Windows rerun — verification evidence

**Study:** JPhysG-106072, *How informative is agreement among nuclear-mass models?*

**Status updated 28 October 2026:** The unmodified three-line
`verification_report.txt` records the successful original Windows
cross-check. The full **original generated `massex.out` has now been
recovered** from the larger original JPhysG-106072 revision archive,
copied byte-for-byte into `DZ31_windows_raw_output/massex.out`, and checked
independently against every DZ31 CSV record using a new Python
fixed-format parser. The original `compile_log.txt` and `model_log.txt`
are not represented as nonempty build logs, and we make no claims about
compiler console output beyond the retained original Windows run report.

## Software and exact method

- System: author's Windows computer; GNU Fortran 16.0.1.
- Official source: unchanged `dz31.f` from the AMDC Duflo–Zuker
  `Duflo-Zuker-program.zip` source distribution.
- Command for the original model:
  `gfortran -std=legacy -ffixed-line-length-none -O0 -o dz31.exe dz31.f`
- Separate, newly written Fortran 2008 checker: `verify_dz31.f90`, compiled
  with `gfortran -std=f2008 -O0 -o verify_dz31.exe verify_dz31.f90`.
- Workflow: `RUN_DZ31_VERIFY.bat` preserves original inputs, compiles both
  programs in a fresh `run_*` folder, executes the official program to
  produce `massex.out`, compares with `DZ31.csv`, and writes the report.
- Archived input fields: `N,Z,mass_excess_MeV` (21,275 model predictions).
  The checker tests a one-to-one match of `(N,Z)`, `A=N+Z`, finite values,
  unique rows, and reported mass excess at two decimal places.
- Acceptance tolerance: 0.011 MeV (allowing a 0.01-MeV rounding-boundary
  difference across compilers); the recorded observed maximum is smaller.

## Raw-output recovery and independent second verification (v9)

- Source container: original uploaded
  `JPhysG-106072 - Major revisions required.zip` (not the later condensed v8).
- Source internal member:
  `revision_work/DZ31_Windows_Verification/DZ31_Windows_Verification/run_32464_15824/massex.out`,
  under the original archive's top-level `JPhysG-106072 - Major revisions required/`.
- Restored location: `raw_source_audit/DZ31_windows_raw_output/massex.out`.
- Length: **957,375 bytes**; **21,275 fixed-format lines** using Fortran
  `(4I4,3F9.2)` (no values invented, rounded or edited).
- SHA-256: `32ad383091ef86d4ed5af28b2e4ad4caab5cee6bb2194ebae1cb83d0431ffb61`.
- Independent check: `verify_recovered_massex_v9.py` checks that every
  line parses into the specified fixed widths; that each unique `(N,Z)` exists
  in the unchanged frozen CSV; that all `A=N+Z` relationships hold; and
  that the **maximum absolute mass-excess difference is 0.000 MeV**.
- Machine-readable check output:
  `DZ31_recovered_raw_verification_v9.json` with status `PASS`.
- The complete earlier archive contains a second copy under
  `run_31867_14946`; both stored raw output files have matching SHA-256.
  Only one byte-identical copy is included to avoid redundant data.

## Verbatim report (also supplied byte-for-byte as a separate file)

```
PASS: 21275 DZ31 predictions; max |Delta| =    0.000 MeV
PASS: Every (N,Z) key and mass number A matched the archive.
PASS: All numeric differences are <= 0.011 MeV.
```

**Interpretation:** All 21,275 archived DZ31 mass excesses reproduce the
official source output **at the archive's 0.01-MeV printed precision**. This
supports source-to-table provenance. It does not establish bitwise equality
of unrounded theoretical values, reproduce the original parameter fitting
campaign or fit roster, or regenerate the independent HFB-27/BRUSLIB export.
The calcium analysis now includes Coraggio et al.'s tabulated values and
vector-digitized GSM estimates under the documented revision-stage amendment.
See `GSM_PROTOCOL_AMENDMENT_2026-11-02.txt` and the `gsm_vector/` audit.

## SHA-256 evidence register

| Artifact | SHA-256 |
| --- | --- |
| Original uploaded report, `DZ31_verification_report.txt` | `6ad1cfb93ddda33efa659046d01b7562ff13547d84ebadb5f5aa4ab6a707da25` |
| Original AMDC Fortran `dz31.f` inside Windows bundle | `15fe5da4cc270cc95f043bff335e3cd75d2de2f87d8511346f28c36b2543b95f` |
| Frozen 21,275-row `DZ31.csv` inside Windows bundle | `cfbb5112b4bc0cbc9d825bd79d13c42e8d9dcc4ff414d3c6042411eeb891dcdd` |
| AMDC source `Duflo-Zuker-program.zip` inside Windows bundle | `7a4d02251d5faed9d432d29f98e263ed359c440742d435ced83c27e78cc725ee` |
| Complete preserved `DZ31_Windows_Verification.zip` | `5b9b634bcd7ae1b14d8d899983f2f265528255f23f7b4a5aef49d7ef1d5390e1` |
| Recovered original generated `massex.out` | `32ad383091ef86d4ed5af28b2e4ad4caab5cee6bb2194ebae1cb83d0431ffb61` |

The Windows ZIP contains the original `dz31.f`, frozen `DZ31.csv`,
`Duflo-Zuker-program.zip`, `verify_dz31.f90`,
`RUN_DZ31_VERIFY.bat`, a source-hash file, and run instructions.
Its `README_WINDOWS.txt` was written **before** the successful run, so
any statement within that unchanged preparatory README that verification
is still pending has been superseded by the dated report above.

**Integrity check:** The preserved text report was copied without editing;
the copy was checked with `cmp` against the uploaded original and its SHA-256.

**Remaining provenance gaps:** Recovering the original BRUSLIB HFB-27
conversion and the fit-mass rosters requires additional sources. The original GSM numerical outputs remain unavailable; the revision uses
explicitly labeled vector-digitized estimates with a separate extraction audit.
