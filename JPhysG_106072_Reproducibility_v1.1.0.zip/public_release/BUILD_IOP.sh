#!/usr/bin/env bash
set -euo pipefail
package_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
build_dir="${package_dir}/build"
mkdir -p -- "$build_dir"
cd -- "${package_dir}/revision_work/submission"
for document in JPhysG_106072_Revised JPhysG_106072_Supplement; do
  for pass_number in 1 2 3; do
    pdflatex -interaction=nonstopmode -halt-on-error -file-line-error \
      "-output-directory=${build_dir}" "${document}.tex"
  done
done
