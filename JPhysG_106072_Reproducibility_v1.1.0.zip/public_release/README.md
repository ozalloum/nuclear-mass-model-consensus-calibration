# Nuclear-mass model consensus calibration

## Study and release scope

**How informative is agreement among nuclear-mass models? Chronology-respecting
tests of error coverage and shell proximity**

Othman H. Y. Zalloum, Palestine Polytechnic University

This is the reproducibility package designated **v1.1.0** for the corrected,
unpublished manuscript. It contains one identified manuscript, one identified
numerical supplement, and the complete scientific reproducibility materials.
The designated release location is:

https://github.com/ozalloum/nuclear-mass-model-consensus-calibration/releases/tag/v1.1.0

The package combines the unchanged original baseline inputs, frozen plan,
configuration and scored data with the independent revision analysis, raw-source
checks, current tables and figures, and DZ31 execution evidence. Earlier
manuscript variants, reviewer correspondence, upload instructions and obsolete
submission-validation records are not included. The baseline scientific files
are retained as reproducibility evidence, not as an alternative manuscript.

## Version policy

Use **v1.1.0** for the corrected manuscript and its results. The existing Git
history and earlier **v1.0.0** baseline release are retained for provenance;
they are not the current manuscript package. This update does not delete or
rewrite earlier commits. The current working tree contains only the corrected
identified manuscript and supplement.

## Read the current manuscript

- [Manuscript PDF](revision_work/submission/JPhysG_106072_Revised.pdf)
- [Numerical supplement PDF](revision_work/submission/JPhysG_106072_Supplement.pdf)
- [Manuscript LaTeX source](revision_work/submission/JPhysG_106072_Revised.tex)
- [Supplement LaTeX source](revision_work/submission/JPhysG_106072_Supplement.tex)

These are the sole manuscript and supplement versions in this tree. The seven
`FigR_*` PDF figures under `revision_work/figures/` are the current manuscript
figures. The original analytical outputs under `nuclear_mass_repo/` document
the fixed baseline and remain inputs or reproducibility targets of the supplied
pipeline; their numbering is not the current manuscript's figure numbering.

## Reproduce the numerical results

Use Python 3.11 or later. The retained v11 numerical audit was performed with
Python 3.12.14; its dependency versions are recorded in `VALIDATION.json`.
From this directory:

```bash
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python reproduce_review_package.py --output ../JPhysG_106072_reproduction
```

The historical runner filename is retained for compatibility. The output
directory must not already exist and must be outside this package. The runner
first checks the SHA-256 manifest, copies the two scientific directories,
regenerates results in the new directory, and compares all 37 supplied CSV
tables with their regenerated counterparts. It writes `REPRODUCTION_RESULT.json`
and per-step logs without overwriting the supplied package. Numeric comparison
uses relative tolerance 1e-10 and absolute tolerance 1e-12 with identical row
and column order; all 37 tables were byte-identical in the retained v11 run.

To verify the current package's file integrity without installing the
scientific dependencies:

```bash
python reproduce_review_package.py --verify-only
```

If GNU Fortran is installed, add `--compile-dz31` to perform a fresh compilation
and model execution. Otherwise the default run checks the official source grid
and independently parses all 21,275 values in the retained original
`massex.out`; it does not claim a new compiler run. The Windows verification
bundle, report, raw output, independent checker and provenance record are
included.

## Build the PDFs

The supplied PDFs are compiled from the identified sources under
`revision_work/submission/`. Use `bash BUILD_IOP.sh` on Linux/macOS or
`BUILD_IOP.bat` on Windows. A working LaTeX installation with `pdflatex` and the
source's packages is required. These scripts compile both documents three
times into the ignored `build/` directory and do not overwrite the deposited
PDFs or their checksums. See `LATEX_README.txt` for details.

## Directory and validation guide

- `nuclear_mass_repo/`: original standardized data, historical AME memberships,
  frozen plan, development/confirmation locks, baseline scoring code and outputs.
- `revision_work/audit_analysis.py`: independent cohort reconstruction and
  revision statistics. No original scoring routine is imported.
- `revision_work/compute_chain_bootstrap_v9.py`: 10,000-draw whole-Z-chain
  intervals for MAE, coverage and the near-shell error difference.
- `revision_work/recheck_calcium.py`: global-model and Coraggio calcium tables.
- `revision_work/regenerate_v8_figures.py`: current manuscript figures; the
  historical filename is retained without changing the numerical method.
- `revision_work/raw_source_audit/`: official inputs, parsers, recreated tables,
  original Windows DZ31 evidence, source checks and raw output.
- `revision_work/tables/` and `revision_work/figures/`: current revision outputs.
- `VALIDATION.json` and `REPRODUCTION_RESULT_v11.json`: retained evidence from
  the completed v11 numerical audit. Their integrity-file counts describe that
  audited package, not the file count of this newly assembled public package.
- `PUBLIC_RELEASE_VALIDATION.json`: pre-publication checks of this public package,
  including unchanged CSVs and executable analysis code.
- `LATEX_VALIDATION.json`: compilation and rendering checks for the two current
  identified documents.
- `SHA256SUMS.json`: current checksums for the tracked release files, excluding
  this manifest itself, caches and generated build output.

The original `nuclear_mass_repo/REPRODUCE.md` describes the baseline pipeline
only. The root runner above covers the baseline, independent revision, and
additional source checks. No numerical analysis was changed when preparing this
public package; only public-release documentation and repository references were
updated from the corrected v11 package.

## Scientific attribution and limits

The retained protocol and configuration are an analysis-plan record, not proof
of independently witnessed preregistration. This package postdates the stated
frozen plan. The study remains a chronology-respecting analysis with a
prespecified plan; it does not establish that every target was excluded from
every model's historical fitting data.

AME evaluations and the FRDM2012, HFB-27, DZ31 and WS4 models retain their
original scientific provenance. Consult the source headers, source readmes,
frozen plan, provenance records and manuscript bibliography. No new license is
asserted over third-party materials, and their attribution has not been removed.

The original BRUSLIB HFB-27 conversion remains unavailable; the RIPL-4
comparison is an independent check with a 0.005-MeV tolerance. DZ31 agreement
concerns the 0.01-MeV printed output, not unrounded values or historical fitting
rosters. The calcium comparison combines a numerical benchmark using Coraggio
et al.'s Table II with qualitative discussion of Li et al.'s Figure 2(b).
No digitized GSM series or numerical residuals for that curve are included.

The Coraggio source-paper checker requires a separately obtained PDF and
`pdftotext`; it is not part of the offline runner. The v11 audit verified all
15 theoretical and 8 experimental Table II entries against PDF page 6 of the
public author preprint, https://arxiv.org/pdf/2006.15196v2. That PDF is not
redistributed. The separate check is recorded in
`revision_work/raw_source_audit/Coraggio_external_verification_v11.json`.

The manuscript's findings concern clustered, short-range historical samples.
They do not establish calibrated predictive uncertainty for deep neutron-rich
extrapolation. The numerical Coraggio benchmark and qualitative GSM discussion
remain explicitly distinct.
