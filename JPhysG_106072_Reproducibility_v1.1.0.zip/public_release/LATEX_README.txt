CURRENT IDENTIFIED MANUSCRIPT AND NUMERICAL SUPPLEMENT
Release candidate designated v1.1.0

Sources and supplied PDFs:
  revision_work/submission/JPhysG_106072_Revised.tex
  revision_work/submission/JPhysG_106072_Revised.pdf
  revision_work/submission/JPhysG_106072_Supplement.tex
  revision_work/submission/JPhysG_106072_Supplement.pdf
  revision_work/submission/iopjournal.cls

The supplied PDFs are the identified, unhighlighted current versions.
There are no reviewer-response or alternate anonymous documents in this tree.

BUILD
  Linux/macOS: bash BUILD_IOP.sh
  Windows:    BUILD_IOP.bat

A working pdflatex installation is required, including the packages declared in
the supplied sources. Run from the package root, or invoke either build script
using its full path. Each source is compiled three times from its source
directory so that ../figures/ resolves correctly. Output goes to build/ at the
package root; the supplied PDFs are not overwritten. Generated build output is
not part of SHA256SUMS.json.

The public release location in the manuscript is designated for v1.1.0. Local
compilation does not publish a release or establish that the remote URL exists.

The distributed PDFs have their document metadata removed after compilation;
the validation process checks that this leaves every rendered page unchanged.
A local rebuild may contain ordinary TeX build metadata and need not have the
same PDF byte hash, even when the visible content is identical.

See LATEX_VALIDATION.json for the checks on the supplied PDFs and README.md for
the separate numerical-reproduction workflow.
