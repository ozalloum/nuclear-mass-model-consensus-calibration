#!/usr/bin/env python3
"""Verify and reproduce the JPhysG-106072 scientific package.

The historical script filename is retained for command-line compatibility.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_integrity() -> int:
    manifest = json.loads((ROOT / "SHA256SUMS.json").read_text(encoding="utf-8"))
    for name, expected in manifest["files"].items():
        path = ROOT / name
        if not path.is_file() or digest(path) != expected:
            raise RuntimeError(f"Integrity check failed: {name}")
    return len(manifest["files"])


def main() -> None:
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--output", type=Path, help="New directory outside this package")
    cli.add_argument("--verify-only", action="store_true")
    cli.add_argument("--compile-dz31", action="store_true",
                     help="Also compile and run the AMDC source with gfortran")
    args = cli.parse_args()
    count = verify_integrity()
    print(f"PASS: SHA-256 verification of {count} packaged files", flush=True)
    if args.verify_only:
        return
    if args.output is None:
        cli.error("provide --output with a new directory, or use --verify-only")
    out = args.output.resolve()
    if out == ROOT or ROOT in out.parents:
        cli.error("--output must be outside the supplied package")
    if out.exists():
        cli.error("--output already exists; choose a new directory")
    if args.compile_dz31 and not shutil.which("gfortran"):
        cli.error("--compile-dz31 requires gfortran on PATH")

    import pandas as pd

    out.mkdir(parents=True)
    for directory in ("nuclear_mass_repo", "revision_work"):
        shutil.copytree(ROOT / directory, out / directory)
    logs = out / "logs"
    logs.mkdir()
    steps = [
        ["nuclear_mass_repo/code/reproduce_repository.py"],
        ["revision_work/raw_source_audit/parse_ame_official.py"],
        ["revision_work/raw_source_audit/parse_ripl4_models.py"],
        ["revision_work/raw_source_audit/verify_recovered_massex_v9.py"],
        ["revision_work/raw_source_audit/reproduce_dz31_with_gfortran.py", "--verify-grid"],
        ["revision_work/audit_analysis.py"],
        ["revision_work/recheck_calcium.py"],
        ["revision_work/compute_chain_bootstrap_v9.py"],
        ["revision_work/regenerate_v8_figures.py"],
    ]
    if args.compile_dz31:
        steps.append(["revision_work/raw_source_audit/reproduce_dz31_with_gfortran.py", "--run"])
    report = {
        "status": "IN_PROGRESS",
        "integrity_files_checked": count,
        "python": sys.version.split()[0],
        "dependencies": {name: importlib.metadata.version(name)
                         for name in ("numpy", "pandas", "scipy", "matplotlib")},
        "fresh_fortran_run": bool(args.compile_dz31),
        "external_coraggio_pdf_check": "NOT_RUN: source paper not bundled",
        "steps": [],
    }
    result = out / "REPRODUCTION_RESULT.json"
    try:
        for index, step in enumerate(steps, 1):
            log_name = f"{index:02d}_{Path(step[0]).stem}.txt"
            print(f"Running {step[0]}", flush=True)
            with (logs / log_name).open("w", encoding="utf-8") as stream:
                process = subprocess.run([sys.executable, *step], cwd=out,
                                         stdout=stream, stderr=subprocess.STDOUT)
            report["steps"].append({"command": step, "returncode": process.returncode,
                                    "log": "logs/" + log_name})
            if process.returncode:
                raise RuntimeError(f"Step failed; inspect logs/{log_name}")

        comparisons = []
        for original in sorted(ROOT.rglob("*.csv")):
            relative = original.relative_to(ROOT)
            generated = out / relative
            if not generated.is_file():
                raise RuntimeError(f"Missing CSV: {relative}")
            exact = digest(original) == digest(generated)
            if not exact:
                pd.testing.assert_frame_equal(
                    pd.read_csv(original), pd.read_csv(generated),
                    check_dtype=False, check_exact=False, rtol=1e-10, atol=1e-12)
            comparisons.append({"file": relative.as_posix(), "byte_identical": exact,
                                "numeric_comparison": "PASS"})
        report["csv_comparisons"] = comparisons
        report["csv_files_compared"] = len(comparisons)
        report["csv_files_byte_identical"] = sum(row["byte_identical"] for row in comparisons)
        # These locked inputs and artifacts must not be modified by reproduction.
        immutable = []
        for directory in ("data", "frozen_protocol", "stage2a_development", "stage2b_confirmation"):
            for source in (ROOT / "nuclear_mass_repo" / directory).rglob("*"):
                if source.is_file():
                    relative = source.relative_to(ROOT)
                    if digest(source) != digest(out / relative):
                        raise RuntimeError(f"Frozen input changed: {relative}")
                    immutable.append(relative.as_posix())
        report["frozen_files_unchanged"] = len(immutable)
        report["status"] = "PASS"
    except Exception as error:
        report["status"] = "FAIL"
        report["error"] = str(error)
        raise
    finally:
        result.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(f"PASS: {len(comparisons)} CSV comparisons; see REPRODUCTION_RESULT.json", flush=True)


if __name__ == "__main__":
    main()
