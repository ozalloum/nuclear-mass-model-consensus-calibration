@echo off
setlocal
set "PACKAGE_DIR=%~dp0"
set "BUILD_DIR=%PACKAGE_DIR%build"
if not exist "%BUILD_DIR%" (
  mkdir "%BUILD_DIR%"
  if errorlevel 1 exit /b 1
)
cd /d "%PACKAGE_DIR%revision_work\submission"
if errorlevel 1 exit /b 1
for %%D in (JPhysG_106072_Revised JPhysG_106072_Supplement) do (
  for /L %%P in (1,1,3) do (
    pdflatex -interaction=nonstopmode -halt-on-error -file-line-error "-output-directory=%BUILD_DIR%" "%%D.tex"
    if errorlevel 1 exit /b 1
  )
)
endlocal
